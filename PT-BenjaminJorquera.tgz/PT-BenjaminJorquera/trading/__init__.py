"""Offline, causal replication of the 2-SMA / LB2 trading experiment."""
