"""Offline training/evaluation orchestration. Test windows never enter fitness."""

from dataclasses import asdict
import math

import numpy as np

from .data import MarketData
from .lb2 import LB2Config, SearchSpace, optimize
from .simulator import (FIXED_PARAMETERS, PUBLISHED_PARAMETERS, IndicatorCache,
                        SimulationConfig, StrategyParameters, simulate, simulate_buy_and_hold)
from .windows import Window


def summarize(factors):
    values = np.asarray(factors, dtype=float)
    if not len(values) or np.any(~np.isfinite(values)) or np.any(values < 0):
        raise ValueError("Summary requires nonempty finite, nonnegative capital factors")
    geometric = float(np.exp(np.mean(np.log(values)))) if np.all(values > 0) else 0.0
    return {"count": len(values), "geometric_mean_factor": geometric,
            "geometric_roi_percent": 100 * (geometric - 1),
            "arithmetic_mean_factor": float(values.mean()),
            "sample_std": float(values.std(ddof=1)) if len(values) > 1 else 0.0,
            "min_factor": float(values.min()), "max_factor": float(values.max()),
            "profitable_windows": int(np.sum(values > 1)),
            "bankrupt_windows": int(np.sum(values == 0))}


class TrainingObjective:
    """Fitness sees only a physically truncated training-prefix dataset."""

    def __init__(self, data: MarketData, windows: list[Window], config: SimulationConfig):
        train = [w for w in windows if w.split == "train"]
        test = [w for w in windows if w.split == "test"]
        if not train or not test:
            raise ValueError("An experiment needs nonempty train and test sets")
        test_start = min(w.start_index for w in test)
        if any(w.end_index > test_start for w in train):
            raise ValueError("Training evaluation overlaps the test holdout")
        self.data = data.slice(0, max(w.end_index for w in train))
        self.windows = train
        self.config = config
        self.cache = IndicatorCache(self.data)

    def __call__(self, parameters: StrategyParameters) -> float:
        returns = []
        for window in self.windows:
            result = simulate(self.data, parameters, self.config, start=window.start_index,
                              end=window.end_index, record_trades=False, indicator_cache=self.cache)
            if result.bankrupt or result.final_capital <= 0:
                return -math.inf
            returns.append(result.log_return)
        return float(np.mean(returns))


def calibrate_random_walk(data: MarketData, windows: list[Window]):
    """Unique adjacent returns contained in training evaluation windows only."""
    mask = np.zeros(len(data), dtype=bool)
    for window in windows:
        if window.split == "train":
            mask[window.start_index:window.end_index] = True
    returns = data.close[1:] / data.close[:-1] - 1
    returns = returns[mask[1:] & mask[:-1]]
    if len(returns) < 2:
        raise ValueError("Random Walk needs at least two observed training returns")
    return {"mean_return": float(returns.mean()),
            "sample_std": float(returns.std(ddof=1)), "observed_returns": len(returns)}


def random_walk_factors(calibration, steps: int, runs: int, seed: int,
                        config: SimulationConfig):
    """Synthetic-path long account factors, not a predictor on actual test prices.

    A normal simple-return draw <= -1 is bankruptcy. For a linear, fixed-quantity
    long account, draw paths and check observed equity at each synthetic step.
    Monte Carlo replicas are not additional independent test periods.
    """
    if steps < 1 or runs < 1:
        raise ValueError("Random Walk steps and runs must be positive")
    rng = np.random.default_rng(seed)
    slip = config.slippage_bps / 10000
    factors = np.empty(runs)
    entry = 1 + slip
    quantity = config.initial_capital * config.leverage / entry
    cash = config.initial_capital - quantity * entry * config.fee_rate
    if cash + quantity * (1 - entry) <= 0:
        return np.zeros(runs)
    # One path at a time bounds memory for long evaluation windows.
    for run in range(runs):
        returns = rng.normal(calibration["mean_return"], calibration["sample_std"], steps)
        if np.any(returns <= -1):
            factors[run] = 0.0
            continue
        prices = np.cumprod(1 + returns)
        equity = cash + quantity * (prices - entry)
        if np.any(equity <= 0):
            factors[run] = 0.0
        else:
            exit_price = float(prices[-1]) * (1 - slip)
            final = cash + quantity * (exit_price - entry) - quantity * exit_price * config.fee_rate
            factors[run] = max(0.0, final) / config.initial_capital
    return factors


def compare(data: MarketData, windows: list[Window], parameters: StrategyParameters,
            config: SimulationConfig = SimulationConfig(), *, seed: int = 42,
            random_walk_runs: int = 100):
    cache = IndicatorCache(data)
    calibration = calibrate_random_walk(data, windows)
    rows, detailed = [], []
    for window in windows:
        if window.split == "purged":
            continue
        bounds = {"start": window.start_index, "end": window.end_index}
        results = {
            "selected_2sma": simulate(data, parameters, config, **bounds, indicator_cache=cache),
            "fixed_2sma": simulate(data, FIXED_PARAMETERS, config, **bounds, indicator_cache=cache),
            "buy_and_hold": simulate_buy_and_hold(data, config, **bounds),
        }
        row = {"window_id": window.window_id, "split": window.split,
               "start_ms": window.start_ms, "end_ms": window.end_ms}
        for name, result in results.items():
            row[name] = result.capital_factor
            detailed.append({"window_id": window.window_id, "split": window.split,
                             "strategy": name, **result.to_dict()})
        rw = random_walk_factors(calibration, window.row_count - 1, random_walk_runs,
                                seed + window.window_id, config)
        row["random_walk_mean"] = float(rw.mean())
        row["random_walk_p05"] = float(np.quantile(rw, 0.05))
        row["random_walk_p95"] = float(np.quantile(rw, 0.95))
        rows.append(row)
    summaries = {}
    for split in ("train", "test"):
        selected = [r for r in rows if r["split"] == split]
        summaries[split] = {name: summarize([r[name] for r in selected])
                            for name in ("selected_2sma", "fixed_2sma", "buy_and_hold", "random_walk_mean")}
    return {"parameters": parameters.to_dict(), "simulation_config": asdict(config),
            "random_walk_calibration": calibration, "random_walk_runs": random_walk_runs,
            "rows": rows, "summary": summaries, "simulations": detailed}


def run_experiment(data: MarketData, windows: list[Window],
                   simulation_config: SimulationConfig = SimulationConfig(),
                   lb2_config: LB2Config = LB2Config(), search_space: SearchSpace = SearchSpace(),
                   *, random_walk_runs: int = 100):
    data.validate()
    minimum_history = min(w.start_index for w in windows)
    if minimum_history < max(search_space.slow_max, FIXED_PARAMETERS.slow):
        raise ValueError("Common warm-up must cover every candidate and the fixed baseline")
    objective = TrainingObjective(data, windows, simulation_config)
    # The published configuration is a deterministic seed, not evidence of a
    # newly optimized result. It is omitted if outside an explicitly smaller domain.
    initial = PUBLISHED_PARAMETERS
    try:
        search_space.encode(initial)
    except ValueError:
        initial = None
    fitted = optimize(objective, search_space, lb2_config, initial)
    evaluation = compare(data, windows, fitted.best_parameters, simulation_config,
                         seed=lb2_config.seed, random_walk_runs=random_walk_runs)
    return {"optimizer": fitted.to_dict(), "evaluation": evaluation}
