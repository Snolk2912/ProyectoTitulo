"""Construct causal evaluation windows and purge train/test overlap."""

from __future__ import annotations

import csv
from dataclasses import asdict, dataclass, replace
import json
import math
from pathlib import Path
from typing import Literal

import numpy as np

from .data import INTERVAL_MS, MarketData, iso_utc, timestamp_ms

_DAY_MS = 24 * 60 * 60 * 1000


@dataclass(frozen=True)
class Window:
    """A half-open evaluation period with indices into the original series."""

    window_id: int
    start_ms: int
    end_ms: int
    start_index: int
    end_index: int
    split: Literal["train", "test", "purged"]

    @property
    def row_count(self) -> int:
        return self.end_index - self.start_index


def _bar_count(days: float, name: str) -> int:
    if isinstance(days, (bool, np.bool_)):
        raise ValueError(f"{name} must be a positive number of days")
    try:
        duration = float(days) * _DAY_MS / INTERVAL_MS
    except (ValueError, TypeError, OverflowError) as exc:
        raise ValueError(f"{name} must be a positive number of days") from exc
    if not math.isfinite(duration) or duration <= 0 or not duration.is_integer():
        raise ValueError(f"{name} must be positive and represent a whole number of 15-minute bars")
    return int(duration)


def build_windows(
    data: MarketData,
    window_days: float = 60,
    step_days: float = 30,
    n_test: int = 8,
    warmup_bars: int = 1344,
    start_ms: int | None = None,
    end_ms: int | None = None,
) -> list[Window]:
    """Build complete evaluation periods with a shared prior-history budget.

    The default first evaluation bar is data.times[warmup_bars]; earlier bars
    are history for every candidate's SMA calculation.  An explicit start is
    never shifted: it must exist in the series and have that much history.
    The default half-open end is one interval after the last observed bar.

    The last n_test windows are test.  Earlier windows ending after the first
    test start are marked purged, retaining the manifest's original indices.
    Train/test therefore share no evaluation bars, while windows within a
    split may overlap as in the paper.  Only complete windows are emitted;
    leftover trailing bars are deliberately not evaluated.
    """
    data.validate()
    bars_per_window = _bar_count(window_days, "window_days")
    step_bars = _bar_count(step_days, "step_days")
    for name, value, minimum in (("n_test", n_test, 1), ("warmup_bars", warmup_bars, 0)):
        if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)) or value < minimum:
            raise ValueError(f"{name} must be an integer >= {minimum}")
    if warmup_bars >= len(data):
        raise ValueError("Insufficient data for the requested warmup history")
    first_time = int(data.times[0])
    series_end = int(data.times[-1]) + INTERVAL_MS
    anchor = int(data.times[warmup_bars]) if start_ms is None else timestamp_ms(start_ms)
    limit = series_end if end_ms is None else timestamp_ms(end_ms)
    for name, value in (("start_ms", anchor), ("end_ms", limit)):
        if value % INTERVAL_MS:
            raise ValueError(f"{name} must align with the UTC 15-minute grid")
    if not first_time <= anchor < series_end:
        raise ValueError("start_ms is outside the observed series")
    if not anchor < limit <= series_end:
        raise ValueError("end_ms must follow start_ms and be within observed half-open coverage")
    start_index = (anchor - first_time) // INTERVAL_MS
    if start_index < warmup_bars:
        raise ValueError("Explicit start_ms has insufficient prior warmup history; start was not moved")
    end_limit_index = (limit - first_time) // INTERVAL_MS
    windows: list[Window] = []
    while start_index + bars_per_window <= end_limit_index:
        end_index = start_index + bars_per_window
        windows.append(Window(
            window_id=len(windows),
            start_ms=first_time + start_index * INTERVAL_MS,
            end_ms=first_time + end_index * INTERVAL_MS,
            start_index=start_index,
            end_index=end_index,
            split="train",
        ))
        start_index += step_bars
    if len(windows) <= n_test:
        raise ValueError("Insufficient complete windows: need the requested test windows and at least one train window")
    first_test_position = len(windows) - int(n_test)
    first_test_start = windows[first_test_position].start_ms
    result = [
        replace(window, split=("test" if position >= first_test_position else
                               "train" if window.end_ms <= first_test_start else "purged"))
        for position, window in enumerate(windows)
    ]
    if not any(window.split == "train" for window in result):
        raise ValueError("Purging overlapping windows leaves no train window; more data or fewer test windows are needed")
    return result


def write_manifest(windows: list[Window], path: str | Path) -> None:
    """Write window metadata as JSON or CSV; never repeat source market rows."""
    target = Path(path)
    records = [dict(asdict(window), start_utc=iso_utc(window.start_ms),
                    end_utc=iso_utc(window.end_ms), row_count=window.row_count)
               for window in windows]
    if target.suffix.lower() not in (".json", ".csv"):
        raise ValueError("Manifest output path must end in .json or .csv")
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.suffix.lower() == ".json":
        target.write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
    else:
        fieldnames = ["window_id", "start_ms", "end_ms", "start_index", "end_index",
                      "split", "start_utc", "end_utc", "row_count"]
        with target.open("w", encoding="utf-8", newline="") as output:
            writer = csv.DictWriter(output, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(records)
