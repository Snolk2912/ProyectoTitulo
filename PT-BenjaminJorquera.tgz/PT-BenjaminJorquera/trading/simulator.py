"""One shared 2-SMA simulator, using closes for decisions and next opens for fills.

The state machine follows Figure 3 of Mathematics 13, 2629. This is an explicit
replication convention: the paper's prose instead describes crossover events.
OHLC extremes are never used to infer an unobserved intrabar path.
"""

from collections import OrderedDict
from dataclasses import asdict, dataclass, field
import math

import numpy as np

from .data import MarketData

WAITING_LONG = "WAITING_LONG"
LONG_OPEN = "LONG_OPEN"
WAITING_SHORT = "WAITING_SHORT"
SHORT_OPEN = "SHORT_OPEN"


@dataclass(frozen=True)
class StrategyParameters:
    fast: int = 171
    slow: int = 356
    alpha_long: float = 0.972
    alpha_short: float = 1.023
    beta_long: float = 3.447
    beta_short: float = 0.472

    def __post_init__(self):
        if isinstance(self.fast, bool) or isinstance(self.slow, bool):
            raise ValueError("SMA periods must be integers")
        if int(self.fast) != self.fast or int(self.slow) != self.slow:
            raise ValueError("SMA periods must be integers")
        if not 2 <= self.fast < self.slow <= 1344 or self.slow < 10:
            raise ValueError("Require 2 <= fast < slow <= 1344 and slow >= 10")
        values = (self.alpha_long, self.alpha_short, self.beta_long, self.beta_short)
        if not all(math.isfinite(v) for v in values):
            raise ValueError("Stop parameters must be finite")
        if not 0.9 <= self.alpha_long < 1 or not 1 < self.alpha_short <= 1.1:
            raise ValueError("Invalid trailing-stop multipliers")
        if not 0 < self.beta_short < 1 < self.beta_long:
            raise ValueError("Require 0 < beta_short < 1 < beta_long")

    def to_dict(self):
        return asdict(self)


PUBLISHED_PARAMETERS = StrategyParameters()
FIXED_PARAMETERS = StrategyParameters(50, 200, 0.95, 1.05, 1.10, 0.90)


@dataclass(frozen=True)
class SimulationConfig:
    initial_capital: float = 1.0
    fee_rate: float = 0.0004
    leverage: float = 1.0
    slippage_bps: float = 0.0

    def __post_init__(self):
        if not all(math.isfinite(v) for v in asdict(self).values()):
            raise ValueError("Simulation settings must be finite")
        if self.initial_capital <= 0 or self.leverage <= 0:
            raise ValueError("Capital and leverage must be positive")
        if not 0 <= self.fee_rate < 1 or not 0 <= self.slippage_bps < 10000:
            raise ValueError("Invalid fees or slippage")
        if self.leverage * self.fee_rate >= 1:
            raise ValueError("Entry commission would exhaust capital")


@dataclass(frozen=True)
class Trade:
    side: str
    signal_time: int
    entry_time: int
    exit_time: int
    entry_price: float
    exit_price: float
    quantity: float
    fee_open: float
    fee_close: float
    gross_pnl: float
    capital_before: float
    capital_after: float
    exit_reason: str

    @property
    def net_pnl(self):
        return self.capital_after - self.capital_before

    def to_dict(self):
        return {**asdict(self), "net_pnl": self.net_pnl}


@dataclass
class SimulationResult:
    initial_capital: float
    final_capital: float
    trade_count: int
    bankrupt: bool
    final_state: str
    trades: list[Trade] = field(default_factory=list)
    transitions: list[dict] = field(default_factory=list)
    equity_curve: list[dict] = field(default_factory=list)

    @property
    def capital_factor(self):
        return self.final_capital / self.initial_capital

    @property
    def log_return(self):
        return math.log(self.capital_factor) if self.capital_factor > 0 else -math.inf

    def to_dict(self):
        return {
            "initial_capital": self.initial_capital,
            "final_capital": self.final_capital,
            "capital_factor": self.capital_factor,
            "roi_percent": 100 * (self.capital_factor - 1),
            "log_return": self.log_return if math.isfinite(self.log_return) else None,
            "trade_count": self.trade_count,
            "bankrupt": self.bankrupt,
            "final_state": self.final_state,
            "trades": [t.to_dict() for t in self.trades],
            "transitions": self.transitions,
            "equity_curve": self.equity_curve,
        }


class IndicatorCache:
    """Causal rolling means with a bounded LRU; no history is repeated per window."""

    def __init__(self, data: MarketData, max_periods: int = 64):
        if max_periods < 2:
            raise ValueError("Indicator cache requires at least two slots")
        data.validate()
        self.data = data
        self.max_periods = max_periods
        self.prefix = np.concatenate(([0.0], np.cumsum(data.close, dtype=np.float64)))
        self.cache = OrderedDict()

    def sma(self, period: int):
        period = int(period)
        if period < 1:
            raise ValueError("SMA period must be positive")
        if period in self.cache:
            self.cache.move_to_end(period)
            return self.cache[period]
        result = np.full(len(self.data), np.nan)
        if period <= len(self.data):
            result[period - 1:] = (self.prefix[period:] - self.prefix[:-period]) / period
        result.flags.writeable = False
        self.cache[period] = result
        if len(self.cache) > self.max_periods:
            self.cache.popitem(last=False)
        return result


def regime_of(fast: float, slow: float) -> int:
    tolerance = 1e-12 * max(abs(fast), abs(slow), 1.0)
    return 1 if fast > slow + tolerance else -1 if fast < slow - tolerance else 0


def exit_decision(side: int, price: float, extreme: float, entry: float,
                  regime: int, parameters: StrategyParameters):
    """Figure 3: profit switches waiting side; stop destination follows regime."""
    if side == 1:
        if price > parameters.beta_long * entry:
            return "take_profit_long", WAITING_SHORT
        if price < parameters.alpha_long * extreme and regime != 0:
            return "trailing_stop_long", WAITING_LONG if regime < 0 else WAITING_SHORT
    else:
        if price < parameters.beta_short * entry:
            return "take_profit_short", WAITING_LONG
        if price > parameters.alpha_short * extreme and regime != 0:
            return "trailing_stop_short", WAITING_SHORT if regime > 0 else WAITING_LONG
    return None


def _bounds(data, start, end):
    end = len(data) if end is None else end
    if isinstance(start, (bool, np.bool_)) or isinstance(end, (bool, np.bool_)) or not isinstance(start, (int, np.integer)) or not isinstance(end, (int, np.integer)):
        raise ValueError("Window indices must be integers")
    if not 0 <= start < end <= len(data):
        raise ValueError("Invalid simulation interval")
    return int(start), int(end)


def simulate(data: MarketData, parameters: StrategyParameters = PUBLISHED_PARAMETERS,
             config: SimulationConfig = SimulationConfig(), *, start: int | None = None,
             end: int | None = None, record_trades: bool = True,
             indicator_cache: IndicatorCache | None = None) -> SimulationResult:
    """Simulate an independent window, with warm-up outside the scored interval.

    A close-t decision fills at open-(t+1), strictly within the interval. Every open
    position is closed at its last close. USDT-linear PnL uses fixed quantity per
    trade, sized from entry equity; fees apply to each executed notional.
    Bankruptcy is an explicit zero-equity rule at observed opens/closes, not an
    exchange liquidation/margin model. Funding is outside this replication.
    """
    start = parameters.slow - 1 if start is None else start
    start, end = _bounds(data, start, end)
    if start < parameters.slow - 1:
        raise ValueError("Insufficient pre-window history for slow SMA")
    cache = indicator_cache or IndicatorCache(data)
    if cache.data is not data:
        raise ValueError("Indicator cache belongs to another dataset")
    fast, slow = cache.sma(parameters.fast), cache.sma(parameters.slow)
    capital = config.initial_capital
    state = WAITING_LONG
    position = None
    pending = None
    trades, transitions, equity_curve = [], [], []
    trade_count = 0
    bankrupt = False
    slip = config.slippage_bps / 10000

    def equity(price):
        return capital if position is None else capital + position["side"] * position["quantity"] * (price - position["entry"])

    def event(action, index, previous, new, *, at_close=False, **details):
        if record_trades:
            transitions.append({"time": int(data.times[index]) + (data.interval_ms if at_close else 0), "action": action,
                                "previous_state": previous, "new_state": new, **details})

    def close_position(index, raw_price, reason, destination, *, at_close=False):
        nonlocal capital, position, state, trade_count, bankrupt
        p = position
        fill = float(raw_price) * (1 - p["side"] * slip)
        pnl = p["side"] * p["quantity"] * (fill - p["entry"])
        fee = p["quantity"] * fill * config.fee_rate
        capital += pnl - fee
        if capital <= 0:
            bankrupt = True
            capital = 0.0  # explicitly limited to the funded account
        if record_trades:
            trades.append(Trade("long" if p["side"] == 1 else "short", p["signal_time"],
                                p["entry_time"], int(data.times[index]) + (data.interval_ms if at_close else 0), p["entry"], fill,
                                p["quantity"], p["fee"], fee, pnl,
                                p["capital_before"], capital, reason))
        previous = state
        position = None
        state = destination
        trade_count += 1
        event("close", index, previous, state, at_close=at_close, reason=reason, price=fill)

    for i in range(start, end):
        open_price = float(data.open[i])
        close_price = float(data.close[i])
        # Positions inherited from the previous close can gap beyond solvency.
        if position is not None and equity(open_price) <= 0:
            close_position(i, open_price, "bankruptcy", WAITING_LONG)
            pending = None
        elif pending is not None:
            kind, info = pending
            pending = None
            if kind == "exit":
                close_position(i, open_price, info[0], info[1])
            elif capital > 0:
                side, signal_time = info
                fill = open_price * (1 + side * slip)
                quantity = capital * config.leverage / fill
                fee = quantity * fill * config.fee_rate
                before = capital
                capital -= fee
                position = {"side": side, "entry": fill, "quantity": quantity,
                            "extreme": fill, "fee": fee, "capital_before": before,
                            "signal_time": signal_time, "entry_time": int(data.times[i])}
                previous = state
                state = LONG_OPEN if side == 1 else SHORT_OPEN
                event("open", i, previous, state, price=fill, signal_time=signal_time)
                if equity(open_price) <= 0:
                    close_position(i, open_price, "bankruptcy", WAITING_LONG)

        regime = regime_of(float(fast[i]), float(slow[i]))
        if position is not None:
            if equity(close_price) <= 0:
                close_position(i, close_price, "bankruptcy", WAITING_LONG, at_close=True)
            else:
                position["extreme"] = (max(position["extreme"], close_price)
                                       if position["side"] == 1 else min(position["extreme"], close_price))
                decision = exit_decision(position["side"], close_price, position["extreme"],
                                         position["entry"], regime, parameters)
                if decision is not None and i + 1 < end:
                    pending = ("exit", decision)
                    event("exit_signal", i, state, state, at_close=True, reason=decision[0])
        elif not bankrupt and capital > 0 and i + 1 < end:
            if state == WAITING_LONG and regime > 0:
                pending = ("entry", (1, int(data.times[i]) + data.interval_ms))
                event("entry_signal_long", i, state, state, at_close=True)
            elif state == WAITING_SHORT and regime < 0:
                pending = ("entry", (-1, int(data.times[i]) + data.interval_ms))
                event("entry_signal_short", i, state, state, at_close=True)
        if record_trades:
            equity_curve.append({"time": int(data.times[i]) + data.interval_ms,
                                 "equity": max(0.0, float(equity(close_price)))})
        if bankrupt:
            break

    if position is not None:
        close_position(end - 1, float(data.close[end - 1]), "end_of_window",
                       WAITING_SHORT if position["side"] == 1 else WAITING_LONG, at_close=True)
        if record_trades:
            equity_curve[-1]["equity"] = capital
    return SimulationResult(config.initial_capital, float(capital), trade_count, bankrupt,
                            state, trades, transitions, equity_curve)


def simulate_buy_and_hold(data: MarketData, config: SimulationConfig = SimulationConfig(),
                          *, start: int = 0, end: int | None = None) -> SimulationResult:
    """Scheduled entry at first open and exit at last close, with identical sizing."""
    start, end = _bounds(data, start, end)
    slip = config.slippage_bps / 10000
    entry = float(data.open[start]) * (1 + slip)
    quantity = config.initial_capital * config.leverage / entry
    fee_open = quantity * entry * config.fee_rate
    cash = config.initial_capital - fee_open
    exit_index, reason, exit_at_close = end - 1, "end_of_window", True
    exit_raw = float(data.close[exit_index])
    for i in range(start, end):
        for at_close, price in ((False, float(data.open[i])), (True, float(data.close[i]))):
            if cash + quantity * (price - entry) <= 0:
                exit_index, exit_raw, reason, exit_at_close = i, price, "bankruptcy", at_close
                break
        if reason == "bankruptcy":
            break
    exit_price = exit_raw * (1 - slip)
    pnl = quantity * (exit_price - entry)
    fee_close = quantity * exit_price * config.fee_rate
    final = max(0.0, cash + pnl - fee_close)
    trade = Trade("long", int(data.times[start]), int(data.times[start]), int(data.times[exit_index]) + (data.interval_ms if exit_at_close else 0),
                  entry, exit_price, quantity, fee_open, fee_close, pnl,
                  config.initial_capital, final, reason)
    return SimulationResult(config.initial_capital, final, 1, final <= 0,
                            WAITING_SHORT, [trade])
