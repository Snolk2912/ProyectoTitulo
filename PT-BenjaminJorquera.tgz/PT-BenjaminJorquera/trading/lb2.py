"""Learning-Based Linear Balancer (LB²), with a maximizing objective.

This implements the structure in Mathematics 9 (2021), 1976, section 3:
SHO moves, separate intensification/diversification roulettes, Soft/Medium/
Hard schemes of 1/2/3 moves, and six periodically fitted linear regressions.
Every candidate is evaluated against the real objective; regression only
chooses how much work to perform and never predicts candidate fitness.

The paper does not fully specify ``countnos``, the regression abscissa, or
replacement policy. Here the SHO cluster contains the elite and population
members whose coordinatewise normalized distance to it is <= M, with each
coordinate of M drawn from [0.5, 1]. Attack averages their hunting positions.
Each regression uses iteration as x and the best actual improving fitness of
its phase/scheme at that iteration as y, retaining observations across learning
intervals. Replacement is greedy per agent and an independent global elite is
preserved. These choices make the adaptation explicit and reproducible.

The paper minimizes benchmark functions; this implementation maximizes
fitness (e.g. mean training-window log return), so roulette selection uses MAX.
The number of objective calls depends on selected schemes and the exact-key
memo cache; an iteration is not an objective-evaluation budget.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
import math
from numbers import Real
from typing import Callable

import numpy as np

from .simulator import StrategyParameters


_PHASES = ("intensification", "diversification")


def _positive_integer(value: int, name: str, minimum: int = 1) -> None:
    if isinstance(value, bool) or not isinstance(value, (int, np.integer)) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")


@dataclass(frozen=True)
class SearchSpace:
    """Six bounded strategy coordinates, searched in normalized [0, 1].

    SMA periods are rounded to integers. ``repair`` projects any bounded
    periods onto fast < slow, preserving the requested domains. The open stop
    bounds at 1 are represented by ``nextafter``, not by allowing a stop with
    zero distance. Continuous values are not rounded: cache keys represent
    identical decoded strategies, rather than an approximate fitness surrogate.
    """

    fast_min: int = 2
    fast_max: int = 1343
    slow_min: int = 10
    slow_max: int = 1344
    alpha_long_min: float = 0.9
    alpha_long_max: float = 1.0
    alpha_short_min: float = 1.0
    alpha_short_max: float = 1.1
    beta_long_min: float = 1.001
    beta_long_max: float = 4.0
    beta_short_min: float = 0.1
    beta_short_max: float = 0.999

    def __post_init__(self) -> None:
        for name in ("fast_min", "fast_max", "slow_min", "slow_max"):
            _positive_integer(getattr(self, name), name)
        if self.fast_min < 2 or self.fast_max > 1343 or self.slow_min < 10 or self.slow_max > 1344:
            raise ValueError("SMA domain must satisfy fast in [2, 1343] and slow in [10, 1344]")
        if self.fast_min > self.fast_max or self.slow_min > self.slow_max:
            raise ValueError("SMA lower bounds must not exceed upper bounds")
        if self.fast_min >= self.slow_max:
            raise ValueError("SMA domains contain no feasible fast < slow pair")
        for prefix in ("alpha_long", "alpha_short", "beta_long", "beta_short"):
            low, high = getattr(self, f"{prefix}_min"), getattr(self, f"{prefix}_max")
            if not isinstance(low, Real) or not isinstance(high, Real):
                raise ValueError(f"{prefix} bounds must be real numbers")
            if not math.isfinite(low) or not math.isfinite(high) or low > high:
                raise ValueError(f"{prefix} bounds must be finite and ordered")
        if not 0.9 <= self.alpha_long_min <= self.alpha_long_max <= 1:
            raise ValueError("alpha_long domain must be within [0.9, 1), with upper 1 allowed as open bound")
        if not 1 <= self.alpha_short_min <= self.alpha_short_max <= 1.1:
            raise ValueError("alpha_short domain must be within (1, 1.1], with lower 1 allowed as open bound")
        if not 1 < self.beta_long_min <= self.beta_long_max:
            raise ValueError("beta_long domain must be above 1")
        if not 0 < self.beta_short_min <= self.beta_short_max < 1:
            raise ValueError("beta_short domain must be within (0, 1)")
        low, high = self._bounds()
        if np.any(low > high):
            raise ValueError("An open stop domain contains no feasible values")

    def _bounds(self) -> tuple[np.ndarray, np.ndarray]:
        low = np.array([
            self.fast_min, self.slow_min, self.alpha_long_min,
            np.nextafter(1.0, math.inf) if self.alpha_short_min == 1 else self.alpha_short_min,
            self.beta_long_min, self.beta_short_min,
        ], dtype=float)
        high = np.array([
            self.fast_max, self.slow_max,
            np.nextafter(1.0, -math.inf) if self.alpha_long_max == 1 else self.alpha_long_max,
            self.alpha_short_max, self.beta_long_max, self.beta_short_max,
        ], dtype=float)
        return low, high

    @staticmethod
    def _vector(vector: np.ndarray) -> np.ndarray:
        vector = np.asarray(vector, dtype=float)
        if vector.shape != (6,) or not np.all(np.isfinite(vector)):
            raise ValueError("Search vector must contain six finite coordinates")
        return vector

    def repair(self, vector: np.ndarray) -> np.ndarray:
        """Clip normalized coordinates and project the integer SMA constraint."""
        repaired = np.clip(self._vector(vector), 0.0, 1.0).copy()
        low, high = self._bounds()
        values = low + repaired * (high - low)
        fast, slow = int(np.rint(values[0])), int(np.rint(values[1]))
        if fast >= slow:
            fast = max(self.fast_min, min(fast, slow - 1))
            if fast >= slow:
                slow = fast + 1
        values[0], values[1] = fast, slow
        span = high - low
        normalized = np.divide(values - low, span, out=np.zeros(6), where=span != 0)
        # Keep continuous coordinates as supplied, avoiding gratuitous roundtrips.
        normalized[2:] = repaired[2:]
        return np.clip(normalized, 0.0, 1.0)

    def decode(self, vector: np.ndarray) -> StrategyParameters:
        vector = self.repair(vector)
        low, high = self._bounds()
        values = np.clip(low + vector * (high - low), low, high)
        return StrategyParameters(
            fast=int(np.rint(values[0])), slow=int(np.rint(values[1])),
            alpha_long=float(values[2]), alpha_short=float(values[3]),
            beta_long=float(values[4]), beta_short=float(values[5]),
        )

    def encode(self, parameters: StrategyParameters) -> np.ndarray:
        values = np.array([
            parameters.fast, parameters.slow, parameters.alpha_long,
            parameters.alpha_short, parameters.beta_long, parameters.beta_short,
        ], dtype=float)
        low, high = self._bounds()
        if not np.all(np.isfinite(values)) or np.any(values < low) or np.any(values > high):
            raise ValueError("Initial strategy lies outside the search space")
        if parameters.fast >= parameters.slow:
            raise ValueError("Initial strategy must have fast < slow")
        if values[0] != np.rint(values[0]) or values[1] != np.rint(values[1]):
            raise ValueError("Initial SMA periods must be integers")
        span = high - low
        return np.divide(values - low, span, out=np.zeros(6), where=span != 0)


@dataclass(frozen=True)
class LB2Config:
    population_size: int = 20
    iterations: int = 100
    learning_interval: int = 20
    seed: int = 42
    winner_probability: float = 0.6

    def __post_init__(self) -> None:
        _positive_integer(self.population_size, "population_size", 2)
        _positive_integer(self.iterations, "iterations")
        _positive_integer(self.learning_interval, "learning_interval")
        _positive_integer(self.seed, "seed", 0)
        if not isinstance(self.winner_probability, Real) or not math.isfinite(self.winner_probability):
            raise ValueError("winner_probability must be finite")
        if not 1 / 3 <= self.winner_probability <= 1:
            raise ValueError("winner_probability must be within [1/3, 1]")


@dataclass
class LB2Result:
    best_parameters: StrategyParameters
    best_score: float
    evaluations: int
    history: list[dict]
    learning_updates: list[dict]
    cache_hits: int = 0
    movement_attempts: int = 0
    improvement_records: dict[str, list[dict]] = field(default_factory=dict)
    config: LB2Config = field(default_factory=LB2Config)
    search_space: SearchSpace = field(default_factory=SearchSpace)

    def to_dict(self) -> dict:
        """JSON-compatible trace, including parameters, config and search domain."""
        def json_value(value):
            if isinstance(value, dict):
                return {key: json_value(item) for key, item in value.items()}
            if isinstance(value, (list, tuple)):
                return [json_value(item) for item in value]
            if isinstance(value, np.generic):
                value = value.item()
            if isinstance(value, float) and not math.isfinite(value):
                return None
            return value

        return json_value(asdict(self))


def _key(parameters: StrategyParameters) -> tuple:
    return (
        parameters.fast, parameters.slow, parameters.alpha_long,
        parameters.alpha_short, parameters.beta_long, parameters.beta_short,
    )


def _coefficients(rng: np.random.Generator, h: float, shape: tuple) -> tuple[np.ndarray, np.ndarray]:
    return 2 * rng.random(shape), 2 * h * rng.random(shape) - h


def _attack(
    current: np.ndarray, elite: np.ndarray, population: np.ndarray,
    h: float, rng: np.random.Generator,
) -> np.ndarray:
    # countnos is underspecified; membership is explicit in normalized units.
    radius = rng.uniform(0.5, 1.0, size=6)
    near = np.all(np.abs(population - elite) <= radius, axis=1)
    not_elite = ~np.all(population == elite, axis=1)
    members = population[near & not_elite]
    members = np.vstack([elite, members])
    b, e = _coefficients(rng, h, members.shape)
    hunting_positions = elite - e * np.abs(b * elite - members)
    return np.mean(hunting_positions, axis=0)


def _explore(
    current: np.ndarray, elite: np.ndarray, population: np.ndarray,
    h: float, rng: np.random.Generator,
) -> tuple[np.ndarray, str]:
    b, e = _coefficients(rng, h, (6,))
    if np.max(np.abs(e)) >= 1:
        peer = population[int(rng.integers(len(population)))]
        return peer - e * np.abs(b * peer - current), "search"
    if rng.random() < 0.5:
        # Equation (1) in this paper prints a signed distance for encircling.
        return elite - e * (b * elite - current), "encircle"
    return elite - e * np.abs(b * elite - current), "hunt"


def _learn_probabilities(
    records: list[dict], iteration: int, config: LB2Config,
) -> tuple[np.ndarray, dict]:
    models = []
    predictions = []
    for scheme in (1, 2, 3):
        # One best fitness per iteration prevents population-size pseudoreplication.
        best_by_iteration: dict[int, float] = {}
        for record in records:
            if record["scheme"] == scheme:
                x = record["iteration"]
                best_by_iteration[x] = max(best_by_iteration.get(x, -math.inf), record["score"])
        points = sorted(best_by_iteration.items())
        model = {"scheme": scheme, "observations": len(points), "slope": None, "intercept": None, "prediction": None}
        if len(points) >= 2:
            x, y = np.asarray(points, dtype=float).T
            centered_x = x - x.mean()
            slope = float(np.dot(centered_x, y - y.mean()) / np.dot(centered_x, centered_x))
            intercept = float(y.mean() - slope * x.mean())
            prediction = float(slope * (iteration + config.learning_interval) + intercept)
            model.update(slope=slope, intercept=intercept, prediction=prediction)
            predictions.append(prediction)
        else:
            predictions.append(None)
        models.append(model)
    probabilities = np.full(3, 1 / 3)
    winner = None
    reason = "insufficient_observations"
    if all(p is not None and math.isfinite(p) for p in predictions):
        predicted = np.asarray(predictions)
        candidates = np.flatnonzero(np.isclose(predicted, np.max(predicted), rtol=1e-9, atol=1e-12))
        if len(candidates) == 1:
            winner = int(candidates[0]) + 1
            probabilities[:] = (1 - config.winner_probability) / 2
            probabilities[winner - 1] = config.winner_probability
            reason = "maximum_prediction"
        else:
            reason = "tied_predictions"
    details = {
        "models": models, "winner": winner, "reason": reason,
        "probabilities": probabilities.tolist(),
    }
    return probabilities, details


def optimize(
    objective: Callable[[StrategyParameters], float],
    space: SearchSpace | None = None,
    config: LB2Config | None = None,
    initial_parameters: StrategyParameters | None = None,
) -> LB2Result:
    """Maximize a scalar objective using real evaluations and LB² learning.

    The supplied objective must be deterministic for the memo cache to be valid.
    Negative infinity marks a bankrupt/infeasible strategy and is never preferred
    over a finite score. An initially infeasible population keeps exploring;
    if the entire budget yields no finite fitness, raise ``ValueError``. NaN and
    positive infinity are objective errors. Traces use null for an infeasible
    initial elite and for improvement measured from negative infinity.
    Initialize RNG locally; optimization neither mutates global RNG state nor
    reads data, writes files, accesses the network, or evaluates test windows.
    """
    if not callable(objective):
        raise ValueError("objective must be callable")
    space = SearchSpace() if space is None else space
    config = LB2Config() if config is None else config
    rng = np.random.default_rng(config.seed)
    population = np.array([space.repair(p) for p in rng.random((config.population_size, 6))])
    if initial_parameters is not None:
        population[0] = space.encode(initial_parameters)
    cache: dict[tuple, float] = {}
    cache_hits = 0

    def evaluate(vector: np.ndarray) -> tuple[float, StrategyParameters]:
        nonlocal cache_hits
        parameters = space.decode(vector)
        key = _key(parameters)
        if key in cache:
            cache_hits += 1
            return cache[key], parameters
        score = objective(parameters)
        if isinstance(score, bool) or not isinstance(score, Real) or math.isnan(score) or score == math.inf:
            raise ValueError(f"objective must return a finite real score or -inf; got {score!r}")
        cache[key] = float(score)
        return float(score), parameters

    scores = np.array([evaluate(p)[0] for p in population])
    best_index = int(np.argmax(scores))
    elite = population[best_index].copy()
    best_score = float(scores[best_index])
    best_parameters = space.decode(elite)
    probabilities = {phase: np.full(3, 1 / 3) for phase in _PHASES}
    records: dict[str, list[dict]] = {phase: [] for phase in _PHASES}
    learning_updates: list[dict] = []
    history = [{
        "iteration": 0, "h": 5.0, "best_score": best_score if math.isfinite(best_score) else None,
        "evaluations": len(cache), "cache_hits": cache_hits,
        "probabilities": {phase: probs.tolist() for phase, probs in probabilities.items()},
    }]
    movement_attempts = 0

    for iteration in range(1, config.iterations + 1):
        h = 5.0 * (1.0 - iteration / config.iterations)
        used_probabilities = {phase: probs.tolist() for phase, probs in probabilities.items()}
        selections = {phase: [0, 0, 0] for phase in _PHASES}
        accepted = {phase: 0 for phase in _PHASES}
        operators = {name: 0 for name in ("attack", "search", "encircle", "hunt")}
        for agent in range(config.population_size):
            for phase in _PHASES:
                scheme = int(rng.choice((1, 2, 3), p=probabilities[phase]))
                selections[phase][scheme - 1] += 1
                before = float(scores[agent])
                for _ in range(scheme):
                    if phase == "intensification":
                        candidate = _attack(population[agent], elite, population, h, rng)
                        operator = "attack"
                    else:
                        candidate, operator = _explore(population[agent], elite, population, h, rng)
                    operators[operator] += 1
                    movement_attempts += 1
                    candidate = space.repair(candidate)
                    score, parameters = evaluate(candidate)
                    if score > scores[agent]:
                        population[agent], scores[agent] = candidate, score
                        accepted[phase] += 1
                    if score > best_score:
                        elite, best_score, best_parameters = candidate.copy(), score, parameters
                if scores[agent] > before:
                    records[phase].append({
                        "iteration": iteration, "agent": agent, "scheme": scheme,
                        "score": float(scores[agent]),
                        "improvement": float(scores[agent] - before) if math.isfinite(before) else None,
                    })
        # Retain the best evaluated candidate even if replacement policy changes.
        if not np.any(np.all(population == elite, axis=1)):
            worst = int(np.argmin(scores))
            population[worst], scores[worst] = elite.copy(), best_score
        if iteration % config.learning_interval == 0:
            update = {"iteration": iteration, "forecast_iteration": iteration + config.learning_interval}
            for phase in _PHASES:
                probabilities[phase], update[phase] = _learn_probabilities(records[phase], iteration, config)
            learning_updates.append(update)
        history.append({
            "iteration": iteration, "h": h, "best_score": best_score if math.isfinite(best_score) else None,
            "evaluations": len(cache), "cache_hits": cache_hits,
            "probabilities_used": used_probabilities,
            "probabilities": {phase: probs.tolist() for phase, probs in probabilities.items()},
            "scheme_selections": selections, "accepted_moves": accepted,
            "operator_attempts": operators,
        })
    if not math.isfinite(best_score):
        raise ValueError(
            f"No feasible candidate after {config.iterations} iterations and {len(cache)} objective evaluations"
        )
    return LB2Result(
        best_parameters=best_parameters, best_score=best_score, evaluations=len(cache),
        history=history, learning_updates=learning_updates, cache_hits=cache_hits,
        movement_attempts=movement_attempts, improvement_records=records,
        config=config, search_space=space,
    )
