"""Local-CSV commands. No command in this module accesses a network."""

import argparse
import csv
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

from .data import iso_utc, load_csv, timestamp_ms
from .experiment import TrainingObjective, compare, run_experiment
from .lb2 import LB2Config, SearchSpace, optimize
from .simulator import (IndicatorCache, PUBLISHED_PARAMETERS, SimulationConfig,
                        StrategyParameters, simulate)
from .windows import build_windows, write_manifest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DATA = PROJECT_ROOT / "data_processed" / "BTCUSDT_15m_20190910_20220131_processed.csv"


def _json(path, value):
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def _csv(path, rows, fieldnames=None):
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fields = fieldnames or (list(rows[0]) if rows else ["window_id", "strategy"])
    with target.open("w", encoding="utf-8", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _source(path):
    source = Path(path).resolve()
    digest = hashlib.sha256()
    with source.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return {"path": str(source), "sha256": digest.hexdigest(),
            "numpy_version": np.__version__, "python_version": sys.version.split()[0]}


def read_parameters(path):
    if path is None:
        return PUBLISHED_PARAMETERS
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if "optimizer" in payload:
        payload = payload["optimizer"]
    payload = payload.get("parameters", payload.get("best_parameters", payload))
    return StrategyParameters(**payload)


def _parameters(args):
    base = read_parameters(getattr(args, "parameters", None)).to_dict()
    for key in base:
        value = getattr(args, key, None)
        if value is not None:
            base[key] = value
    return StrategyParameters(**base)


def _simulation_config(args):
    values = asdict(SimulationConfig())
    parameter_path = getattr(args, "parameters", None)
    if parameter_path is not None:
        payload = json.loads(parameter_path.read_text(encoding="utf-8"))
        values.update(payload.get("simulation_config", {}))
    for name in values:
        explicit = getattr(args, name, None)
        if explicit is not None:
            values[name] = explicit
    return SimulationConfig(**values)


def _windows(data, args):
    return build_windows(data, args.window_days, args.step_days, args.test_windows,
                         args.warmup_bars,
                         timestamp_ms(args.start) if args.start else None,
                         timestamp_ms(args.end) if args.end else None)


def _selected_window(windows, window_id):
    for window in windows:
        if window.window_id == window_id:
            return window
    raise ValueError(f"Window {window_id} does not exist; available IDs: 0..{len(windows) - 1}")


def _optimizer_config(args):
    config = LB2Config(args.population, args.iterations, args.learning_interval, args.seed)
    space = SearchSpace(**json.loads(args.search_space.read_text(encoding="utf-8"))) if args.search_space else SearchSpace()
    if args.warmup_bars < space.slow_max:
        raise ValueError("warmup-bars must cover the complete slow-period search domain")
    return config, space


def _write_evaluation(directory, evaluation, save_equity=False):
    directory = Path(directory)
    _csv(directory / "comparison.csv", evaluation["rows"])
    _json(directory / "evaluation.json", {k: v for k, v in evaluation.items() if k != "simulations"})
    trades, equities = [], []
    for result in evaluation["simulations"]:
        metadata = {"window_id": result["window_id"], "split": result["split"], "strategy": result["strategy"]}
        trades.extend({**metadata, **trade} for trade in result["trades"])
        if save_equity:
            equities.extend({**metadata, **observation} for observation in result["equity_curve"])
    _csv(directory / "trades.csv", trades, ["window_id", "split", "strategy", "side",
         "signal_time", "entry_time", "exit_time", "entry_price", "exit_price", "quantity",
         "fee_open", "fee_close", "gross_pnl", "capital_before", "capital_after", "exit_reason", "net_pnl"])
    if save_equity:
        _csv(directory / "equity.csv", equities, ["window_id", "split", "strategy", "time", "equity"])


def _print_summary(evaluation):
    print("Test: factor geométrico; ROI geométrico; media aritmética")
    for name, summary in evaluation["summary"]["test"].items():
        print(f"  {name}: {summary['geometric_mean_factor']:.6f}; "
              f"{summary['geometric_roi_percent']:.3f}%; "
              f"{summary['arithmetic_mean_factor']:.6f}")


def _write_comparison_plots(rows, directory):
    """Plot independent-window results; factors are never compounded across windows."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if not rows:
        raise ValueError("Comparison plots require evaluation rows")
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    strategies = [("selected_2sma", "2-SMA seleccionada"),
                  ("fixed_2sma", "2-SMA fija"),
                  ("buy_and_hold", "Buy and Hold"),
                  ("random_walk_mean", "Random Walk (media)")]
    positions = np.arange(len(rows))
    width = 0.19
    fig, axis = plt.subplots(figsize=(max(10, min(20, len(rows) * 0.45)), 6))
    for offset, (name, label) in enumerate(strategies):
        roi = [100 * (row[name] - 1) for row in rows]
        axis.bar(positions + (offset - 1.5) * width, roi, width=width, label=label)
    axis.set_xticks(positions, [f"{row['window_id']} ({row['split']})" for row in rows], rotation=60)
    axis.set_title("ROI por ventana (capital inicial reiniciado)")
    axis.set_xlabel("Ventana y conjunto")
    axis.set_ylabel("ROI (%)")
    axis.axhline(0, color="black", linewidth=0.7)
    axis.grid(axis="y", alpha=0.2)
    axis.legend()
    fig.tight_layout()
    fig.savefig(directory / "roi_by_window.png", dpi=150)
    plt.close(fig)

    test_rows = [row for row in rows if row["split"] == "test"]
    if not test_rows:
        raise ValueError("Comparison plots require test rows")
    test_ids = np.asarray([row["window_id"] for row in test_rows])
    fig, axis = plt.subplots(figsize=(10, 6))
    for name, label in strategies:
        axis.plot(test_ids, [row[name] for row in test_rows], marker="o", label=label)
    if all("random_walk_p05" in row and "random_walk_p95" in row for row in test_rows):
        axis.fill_between(test_ids, [row["random_walk_p05"] for row in test_rows],
                          [row["random_walk_p95"] for row in test_rows], alpha=0.12,
                          label="Random Walk P05–P95")
    axis.set_xticks(test_ids)
    axis.set_title("Factor de capital por ventana test")
    axis.set_xlabel("Ventana test")
    axis.set_ylabel("Capital final / capital inicial (sin acumular)")
    axis.axhline(1, color="black", linewidth=0.7)
    axis.grid(axis="y", alpha=0.2)
    axis.legend()
    fig.tight_layout()
    fig.savefig(directory / "capital_by_test_window.png", dpi=150)
    plt.close(fig)


def _plot(data, window, args, provenance=None):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    parameters = _parameters(args)
    cache = IndicatorCache(data)
    start, end = window.start_index, window.end_index
    times = (data.times[start:end] + data.interval_ms).astype("datetime64[ms]")
    fig, axis = plt.subplots(figsize=(15, 6))
    axis.plot(times, data.close[start:end], label="Close", linewidth=0.8)
    axis.plot(times, cache.sma(parameters.fast)[start:end], label=f"SMA {parameters.fast}")
    if not args.single:
        axis.plot(times, cache.sma(parameters.slow)[start:end], label=f"SMA {parameters.slow}")
    simulation = None
    if args.fsm:
        config = _simulation_config(args)
        simulation = simulate(data, parameters, config, start=start, end=end, indicator_cache=cache)
        for action, marker in (("open", "^"), ("close", "x")):
            events = [event for event in simulation.transitions if event["action"] == action]
            if events:
                axis.scatter(np.asarray([e["time"] for e in events], dtype="datetime64[ms]"),
                             [e["price"] for e in events], marker=marker, label=action)
    title = "SMA" if args.single else "2-SMA"
    axis.set_title(f"{title} — ventana {window.window_id} ({window.split})")
    axis.set_xlabel("UTC")
    axis.set_ylabel("USDT")
    axis.legend()
    fig.tight_layout()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.output, dpi=150)
    plt.close(fig)
    if simulation is not None:
        _json(args.output.with_suffix(".json"), {
            "source": provenance if provenance is not None else _source(args.data),
            "window": asdict(window), "parameters": parameters.to_dict(),
            "simulation_config": asdict(config), **simulation.to_dict(),
        })


def parser():
    result = argparse.ArgumentParser(description="2-SMA y LB2 sobre CSV locales; nunca descarga datos.")
    commands = result.add_subparsers(dest="command", required=True)
    for name in ("audit", "windows", "simulate", "baselines", "optimize", "run", "plot"):
        command = commands.add_parser(name)
        command.add_argument("--data", type=Path, default=DEFAULT_DATA)
        default = PROJECT_ROOT / "results" / (name + (".json" if name in ("audit", "simulate") else ".csv" if name == "windows" else ".png" if name == "plot" else ""))
        command.add_argument("--output", type=Path, default=default)
        if name == "audit":
            continue
        command.add_argument("--window-days", type=float, default=60)
        command.add_argument("--step-days", type=float, default=30)
        command.add_argument("--test-windows", type=int, default=8)
        command.add_argument("--warmup-bars", type=int, default=1344)
        command.add_argument("--start", help="Primera evaluación UTC, inclusive; debe tener historia previa")
        command.add_argument("--end", help="Límite UTC exclusivo")
        if name == "windows":
            continue
        command.add_argument("--initial-capital", type=float, help="Default: 1; hereda JSON de parámetros")
        command.add_argument("--fee-rate", type=float, help="Default: 0.0004; hereda JSON de parámetros")
        command.add_argument("--leverage", type=float, help="Default: 1; hereda JSON de parámetros")
        command.add_argument("--slippage-bps", type=float, help="Default: 0; hereda JSON de parámetros")
        if name in ("simulate", "baselines", "plot"):
            command.add_argument("--parameters", type=Path, help="JSON de parámetros publicados, manuales o entrenados")
            command.add_argument("--fast", type=int)
            command.add_argument("--slow", type=int)
            for parameter in ("alpha_long", "alpha_short", "beta_long", "beta_short"):
                command.add_argument("--" + parameter.replace("_", "-"), dest=parameter, type=float)
        if name in ("simulate", "plot"):
            command.add_argument("--window-id", type=int, default=0)
        if name in ("baselines", "run"):
            command.add_argument("--random-walk-runs", type=int, default=100)
            command.add_argument("--save-equity", action="store_true")
            command.add_argument("--plots", action="store_true", help="Guarda gráficos comparativos (requiere matplotlib)")
        if name in ("baselines", "run", "optimize"):
            command.add_argument("--seed", type=int, default=42)
        if name in ("run", "optimize"):
            command.add_argument("--population", type=int, default=20)
            command.add_argument("--iterations", type=int, default=100)
            command.add_argument("--learning-interval", type=int, default=20)
            command.add_argument("--search-space", type=Path, help="JSON de límites SearchSpace")
        if name == "plot":
            command.add_argument("--single", action="store_true")
            command.add_argument("--fsm", action="store_true")
    return result


def main(argv=None):
    arguments = parser()
    args = arguments.parse_args(argv)
    try:
        data = load_csv(args.data)
        provenance = _source(args.data)
        if args.command == "audit":
            report = {"source": provenance, "valid": True, "rows": len(data),
                      "first_open_utc": iso_utc(int(data.times[0])),
                      "end_exclusive_utc": iso_utc(int(data.times[-1]) + data.interval_ms),
                      "interval_minutes": 15}
            _json(args.output, report)
            print(f"Datos válidos: {len(data)} velas de 15 minutos.")
        else:
            windows = _windows(data, args)
            counts = {split: sum(w.split == split for w in windows) for split in ("train", "test", "purged")}
            print(f"Ventanas: {counts}")
            if args.command == "windows":
                write_manifest(windows, args.output)
            elif args.command == "simulate":
                window = _selected_window(windows, args.window_id)
                simulation = simulate(data, _parameters(args), _simulation_config(args),
                                      start=window.start_index, end=window.end_index)
                _json(args.output, {"source": provenance, "window": asdict(window),
                                    "parameters": _parameters(args).to_dict(),
                                    "simulation_config": asdict(_simulation_config(args)), **simulation.to_dict()})
                print(f"Capital final: {simulation.final_capital:.6f}; ROI: {100*(simulation.capital_factor-1):.3f}%")
            elif args.command == "plot":
                _plot(data, _selected_window(windows, args.window_id), args, provenance)
            elif args.command == "baselines":
                evaluation = compare(data, windows, _parameters(args), _simulation_config(args),
                                     seed=args.seed, random_walk_runs=args.random_walk_runs)
                _write_evaluation(args.output, evaluation, args.save_equity)
                if args.plots:
                    _write_comparison_plots(evaluation["rows"], args.output)
                write_manifest(windows, args.output / "windows.csv")
                _json(args.output / "source.json", provenance)
                _print_summary(evaluation)
            else:
                config, space = _optimizer_config(args)
                if args.command == "run":
                    payload = run_experiment(data, windows, _simulation_config(args), config, space,
                                             random_walk_runs=args.random_walk_runs)
                    optimizer = payload["optimizer"]
                    _write_evaluation(args.output, payload["evaluation"], args.save_equity)
                    if args.plots:
                        _write_comparison_plots(payload["evaluation"]["rows"], args.output)
                    _print_summary(payload["evaluation"])
                else:
                    objective = TrainingObjective(data, windows, _simulation_config(args))
                    initial = PUBLISHED_PARAMETERS
                    try:
                        space.encode(initial)
                    except ValueError:
                        initial = None
                    optimizer = optimize(objective, space, config, initial).to_dict()
                _json(args.output / "optimizer.json", optimizer)
                _json(args.output / "parameters.json", {"parameters": optimizer["best_parameters"],
                      "training_mean_log_return": optimizer["best_score"],
                      "simulation_config": asdict(_simulation_config(args)), "source": provenance})
                _json(args.output / "experiment.json", {"source": provenance,
                      "window_days": args.window_days, "step_days": args.step_days,
                      "test_windows": args.test_windows, "warmup_bars": args.warmup_bars,
                      "requested_start": args.start, "requested_end": args.end,
                      "simulation_config": asdict(_simulation_config(args)), "lb2": asdict(config),
                      "search_space": asdict(space), "window_counts": counts,
                      "specification": "docs/replication.md"})
                write_manifest(windows, args.output / "windows.csv")
                print(f"LB2: {optimizer['evaluations']} evaluaciones; fitness train={optimizer['best_score']:.6f}")
        print(f"Salida: {args.output.resolve()}")
        return 0
    except (ValueError, OSError, TypeError, KeyError, ImportError) as error:
        print(f"Error: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
