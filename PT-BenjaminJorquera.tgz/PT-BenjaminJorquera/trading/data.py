"""Read and validate local 15-minute OHLCV data without network access.

The original processed CSV is the source of truth.  Validation never sorts,
deduplicates, fills gaps, or otherwise changes the observed market series.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
import re

import numpy as np

INTERVAL_MS = 15 * 60 * 1000
_EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)
_FIELDS = ("open", "high", "low", "close", "volume")


def timestamp_ms(text: str | int) -> int:
    """Parse integer epoch milliseconds or ISO time with an explicit zone.

    A date alone (YYYY-MM-DD) means midnight UTC.  A datetime without a zone
    is rejected rather than interpreted in the computer's local timezone.
    Sub-millisecond precision is rejected to avoid silently changing times.
    """
    if isinstance(text, (int, np.integer)) and not isinstance(text, (bool, np.bool_)):
        value = int(text)
    elif isinstance(text, str):
        value_text = text.strip()
        if re.fullmatch(r"[+-]?\d+", value_text):
            value = int(value_text)
        else:
            if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value_text):
                value_text += "T00:00:00+00:00"
            elif value_text.endswith("Z"):
                value_text = value_text[:-1] + "+00:00"
            try:
                parsed = datetime.fromisoformat(value_text)
            except ValueError as exc:
                raise ValueError(f"Invalid ISO or epoch-millisecond time: {text!r}") from exc
            if parsed.tzinfo is None or parsed.utcoffset() is None:
                raise ValueError(f"Timestamp needs an explicit timezone: {text!r}")
            if parsed.microsecond % 1000:
                raise ValueError(f"Timestamp has sub-millisecond precision: {text!r}")
            delta = parsed.astimezone(timezone.utc) - _EPOCH
            value = delta.days * 86_400_000 + delta.seconds * 1000 + delta.microseconds // 1000
    else:
        raise ValueError("Time must be ISO text or an integer epoch-millisecond value")
    if value < np.iinfo(np.int64).min or value > np.iinfo(np.int64).max:
        raise ValueError("Epoch-millisecond timestamp is outside the int64 range")
    return value


def iso_utc(ms: int) -> str:
    """Format epoch milliseconds as an ISO UTC datetime ending in Z."""
    value = timestamp_ms(ms)
    seconds, milliseconds = divmod(value, 1000)
    # fromtimestamp is exact for the integral-second part; attach milliseconds
    # separately instead of converting an arbitrary millisecond int to float.
    date = datetime.fromtimestamp(seconds, tz=timezone.utc)
    result = date.strftime("%Y-%m-%dT%H:%M:%S")
    if milliseconds:
        result += f".{milliseconds:03d}"
    return result + "Z"


@dataclass
class MarketData:
    """A single chronological market series; times are candle-open UTC ms."""

    times: np.ndarray
    open: np.ndarray
    high: np.ndarray
    low: np.ndarray
    close: np.ndarray
    volume: np.ndarray
    interval_ms: int = INTERVAL_MS

    def __post_init__(self) -> None:
        # Reject fractional/float timestamps rather than silently truncating
        # them during conversion to the public int64 representation.
        raw_times = np.asarray(self.times)
        if raw_times.dtype.kind not in "iu":
            raise ValueError("times must contain integer epoch milliseconds")
        if raw_times.dtype.kind == "u" and raw_times.size and np.max(raw_times) > np.iinfo(np.int64).max:
            raise ValueError("Timestamp is outside the int64 range")
        self.times = raw_times.astype(np.int64, copy=False)
        for field in _FIELDS:
            try:
                setattr(self, field, np.asarray(getattr(self, field), dtype=np.float64))
            except (ValueError, TypeError) as exc:
                raise ValueError(f"{field} must be numeric") from exc

    def __len__(self) -> int:
        return len(self.times)

    def slice(self, start: int, end: int) -> MarketData:
        """Return the half-open index slice [start, end), retaining cadence.

        Bounds must be explicit and in range.  Empty slices may be represented
        but cannot pass validate(), which requires a nonempty market series.
        """
        for name, bound in (("start", start), ("end", end)):
            if isinstance(bound, (bool, np.bool_)) or not isinstance(bound, (int, np.integer)):
                raise ValueError(f"{name} must be an integer index")
        if not 0 <= start <= end <= len(self):
            raise ValueError("Slice must satisfy 0 <= start <= end <= len(data)")
        return MarketData(
            self.times[start:end],
            *(getattr(self, field)[start:end] for field in _FIELDS),
            interval_ms=self.interval_ms,
        )

    def validate(self) -> None:
        """Reject malformed prices, duplicated bars, missing bars and gaps."""
        if (isinstance(self.interval_ms, (bool, np.bool_))
                or not isinstance(self.interval_ms, (int, np.integer))
                or self.interval_ms != INTERVAL_MS):
            raise ValueError("Only 15-minute data (interval_ms=900000) is supported")
        if self.times.ndim != 1 or self.times.size == 0:
            raise ValueError("times must be a nonempty one-dimensional array")
        if self.times.dtype != np.dtype(np.int64):
            raise ValueError("times must contain int64 epoch milliseconds")
        for field in _FIELDS:
            values = getattr(self, field)
            if values.ndim != 1 or len(values) != len(self):
                raise ValueError(f"{field} must be one-dimensional and match times length")
            if not np.all(np.isfinite(values)):
                raise ValueError(f"{field} contains non-finite values")
            if field == "volume":
                if np.any(values < 0):
                    raise ValueError("volume must be nonnegative")
            elif np.any(values <= 0):
                raise ValueError(f"{field} prices must be positive")
        if self.times[0] % INTERVAL_MS:
            raise ValueError("Candle timestamps must align with the UTC 15-minute grid")
        # The independent ordering check catches wrapping/reversed pairs;
        # np.diff then rejects any actual gap, including int64 overflow.
        if (np.any(self.times[1:] <= self.times[:-1])
                or np.any(np.diff(self.times) != INTERVAL_MS)):
            raise ValueError("Timestamps must be unique, increasing, and exactly 15 minutes apart; no gaps")
        if np.any(self.high < np.maximum(self.open, self.close)):
            raise ValueError("high must be at least max(open, close)")
        if np.any(self.low > np.minimum(self.open, self.close)):
            raise ValueError("low must be at most min(open, close)")
        if np.any(self.low > self.high):
            raise ValueError("low must not exceed high")


def load_csv(path: str | Path) -> MarketData:
    """Read an original OHLCV CSV and validate it without repairing rows.

    Required columns: open_time, open, high, low, close, volume.  Binance's
    extra columns are permitted.  A generated windows CSV is rejected because
    it repeats market observations and must not become a market-data source.
    """
    values: dict[str, list] = {name: [] for name in ("times", *_FIELDS)}
    with Path(path).open("r", encoding="utf-8-sig", newline="") as source:
        reader = csv.DictReader(source)
        if reader.fieldnames is None:
            raise ValueError("CSV is empty or missing a header")
        if len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise ValueError("CSV contains duplicate column names")
        if "window_id" in reader.fieldnames or "window_start" in reader.fieldnames:
            raise ValueError("Use the original processed OHLCV CSV, not a windows CSV with repeated observations")
        missing = set(("open_time", *_FIELDS)) - set(reader.fieldnames)
        if missing:
            raise ValueError("CSV is missing required columns: " + ", ".join(sorted(missing)))
        for row_number, row in enumerate(reader, start=2):
            if None in row:
                raise ValueError(f"CSV row {row_number} contains more values than its header")
            try:
                values["times"].append(timestamp_ms(row["open_time"]))
                for field in _FIELDS:
                    values[field].append(float(row[field]))
            except (ValueError, TypeError) as exc:
                raise ValueError(f"Invalid CSV row {row_number}: {exc}") from exc
    data = MarketData(
        np.asarray(values["times"], dtype=np.int64),
        *(np.asarray(values[field], dtype=np.float64) for field in _FIELDS),
    )
    data.validate()
    return data
