"""Offline experiment isolation, aggregation, and comparable-cost checks."""

import json
import math
import unittest

import numpy as np

from trading.data import INTERVAL_MS, MarketData
from trading.experiment import (
    TrainingObjective, calibrate_random_walk, compare, random_walk_factors,
    run_experiment, summarize,
)
from trading.lb2 import LB2Config, SearchSpace
from trading.simulator import SimulationConfig, StrategyParameters, simulate, simulate_buy_and_hold
from trading.windows import build_windows


def market_from_close(close, open_prices=None):
    close = np.asarray(close, dtype=float)
    opening = np.r_[close[0], close[:-1]] if open_prices is None else np.asarray(open_prices, dtype=float)
    data = MarketData(
        np.arange(len(close), dtype=np.int64) * INTERVAL_MS,
        opening, np.maximum(opening, close) * 1.001,
        np.minimum(opening, close) * 0.999, close, np.ones(len(close)),
    )
    data.validate()
    return data


def synthetic_data(warmup=1344, evaluation_bars=240, flat=False):
    history = np.linspace(90.0, 100.0, warmup)
    index = np.arange(evaluation_bars)
    prices = np.full(evaluation_bars, 100.0) if flat else 100 * np.exp(0.002 * index + 0.08 * np.sin(index / 9))
    return market_from_close(np.r_[history, prices])


def copy_market(data):
    return MarketData(
        data.times.copy(), data.open.copy(), data.high.copy(), data.low.copy(),
        data.close.copy(), data.volume.copy(),
    )


class ExperimentTests(unittest.TestCase):
    def setUp(self):
        self.data = synthetic_data()
        self.windows = build_windows(self.data, window_days=0.5, step_days=0.5, n_test=1)
        self.parameters = StrategyParameters(4, 14, 0.95, 1.05, 1.1, 0.9)
        self.config = SimulationConfig(fee_rate=0.0004)

    def test_training_objective_is_independent_of_every_holdout_price(self):
        first_test = min(w.start_index for w in self.windows if w.split == "test")
        changed = copy_market(self.data)
        scale = np.linspace(10, 30, len(changed) - first_test)
        for name in ("open", "high", "low", "close"):
            getattr(changed, name)[first_test:] *= scale
        changed.validate()
        before = TrainingObjective(self.data, self.windows, self.config)
        after = TrainingObjective(changed, self.windows, self.config)
        self.assertEqual(len(before.data), first_test)
        self.assertEqual(before(self.parameters), after(self.parameters))
        np.testing.assert_array_equal(before.cache.prefix, after.cache.prefix)

    def test_objective_is_mean_log_return_and_summary_reports_geometric_factor(self):
        objective = TrainingObjective(self.data, self.windows, self.config)
        factors = [
            simulate(self.data, self.parameters, self.config,
                     start=w.start_index, end=w.end_index).capital_factor
            for w in self.windows if w.split == "train"
        ]
        expected = float(np.mean(np.log(factors)))
        self.assertAlmostEqual(objective(self.parameters), expected)
        self.assertGreater(abs(expected - math.log(float(np.mean(factors)))), 1e-7)
        summary = summarize([0.5, 2.0])
        self.assertEqual(summary["geometric_mean_factor"], 1.0)
        self.assertEqual(summary["arithmetic_mean_factor"], 1.25)
        self.assertEqual(summary["geometric_roi_percent"], 0.0)
        self.assertEqual(summarize([1.0, 0.0])["bankrupt_windows"], 1)
        self.assertEqual(summarize([1.0, 0.0])["geometric_mean_factor"], 0.0)

    def test_random_walk_calibration_uses_unique_overlapping_training_returns(self):
        windows = build_windows(self.data, window_days=0.5, step_days=0.25, n_test=1)
        expected_indices = sorted({
            index for window in windows if window.split == "train"
            for index in range(window.start_index, window.end_index - 1)
        })
        returns = self.data.close[1:] / self.data.close[:-1] - 1
        expected_returns = returns[expected_indices]
        calibration = calibrate_random_walk(self.data, windows)
        self.assertEqual(calibration["observed_returns"], len(expected_indices))
        self.assertAlmostEqual(calibration["mean_return"], float(expected_returns.mean()))
        self.assertAlmostEqual(calibration["sample_std"], float(expected_returns.std(ddof=1)))
        raw_count = sum(w.row_count - 1 for w in windows if w.split == "train")
        self.assertLess(calibration["observed_returns"], raw_count)
        changed = copy_market(self.data)
        first_test = min(w.start_index for w in windows if w.split == "test")
        for name in ("open", "high", "low", "close"):
            getattr(changed, name)[:1344] *= 777
            getattr(changed, name)[first_test:] *= np.linspace(30, 80, len(changed) - first_test)
        changed.validate()
        self.assertEqual(calibration, calibrate_random_walk(changed, windows))

    def test_every_baseline_charges_identical_fees_slippage_and_leverage(self):
        data = synthetic_data(flat=True)
        windows = build_windows(data, window_days=0.5, step_days=0.5, n_test=1)
        config = SimulationConfig(initial_capital=7, fee_rate=0.01, leverage=1.5, slippage_bps=50)
        comparison = compare(data, windows, self.parameters, config, random_walk_runs=4)
        first = comparison["rows"][0]
        slip = config.slippage_bps / 10000
        expected = (
            1 - config.leverage * config.fee_rate
            + config.leverage * ((1 - slip) - (1 + slip)) / (1 + slip)
            - config.leverage * (1 - slip) * config.fee_rate / (1 + slip)
        )
        for strategy in ("selected_2sma", "fixed_2sma", "buy_and_hold", "random_walk_mean"):
            self.assertAlmostEqual(first[strategy], expected, msg=strategy)
        for result in comparison["simulations"]:
            self.assertEqual(result["initial_capital"], config.initial_capital)
        self.assertEqual(comparison["simulation_config"]["slippage_bps"], 50)

    def test_random_walk_local_seed_is_deterministic_and_does_not_change_global_rng(self):
        calibration = calibrate_random_walk(self.data, self.windows)
        np.random.seed(123)
        expected_global = np.random.random(3)
        np.random.seed(123)
        first = random_walk_factors(calibration, 30, 6, 42, self.config)
        second = random_walk_factors(calibration, 30, 6, 42, self.config)
        different_seed = random_walk_factors(calibration, 30, 6, 43, self.config)
        np.testing.assert_array_equal(first, second)
        self.assertFalse(np.array_equal(first, different_seed))
        np.testing.assert_array_equal(np.random.random(3), expected_global)

    def test_random_walk_cannot_recover_from_immediate_entry_bankruptcy(self):
        config = SimulationConfig(leverage=100, fee_rate=0.001, slippage_bps=1000)
        # Fees plus adverse entry slippage exhaust equity before the first step.
        # A later doubling cannot rescue an account that was already insolvent.
        data = market_from_close([100, 200], open_prices=[100, 100])
        reference = simulate_buy_and_hold(data, config)
        self.assertTrue(reference.bankrupt)
        factors = random_walk_factors({"mean_return": 1.0, "sample_std": 0.0}, 1, 3, 42, config)
        np.testing.assert_array_equal(factors, [0, 0, 0])

    def test_runner_rejects_insufficient_common_warmup(self):
        data = synthetic_data(warmup=199)
        windows = build_windows(data, window_days=0.5, step_days=0.5, n_test=1, warmup_bars=199)
        space = SearchSpace(fast_max=8, slow_max=20)
        with self.assertRaisesRegex(ValueError, "Common warm-up"):
            run_experiment(data, windows, search_space=space)

    def test_small_offline_experiment_runs_end_to_end(self):
        space = SearchSpace(fast_max=8, slow_max=20)
        lb2 = LB2Config(population_size=4, iterations=2, learning_interval=1, seed=5)
        result = run_experiment(self.data, self.windows, self.config, lb2, space, random_walk_runs=3)
        self.assertEqual(len(result["optimizer"]["history"]), 3)
        self.assertEqual(len(result["evaluation"]["rows"]), 5)
        self.assertEqual(result["evaluation"]["summary"]["train"]["selected_2sma"]["count"], 4)
        self.assertEqual(result["evaluation"]["summary"]["test"]["selected_2sma"]["count"], 1)
        parameters = StrategyParameters(**result["optimizer"]["best_parameters"])
        training_score = TrainingObjective(self.data, self.windows, self.config)(parameters)
        self.assertAlmostEqual(result["optimizer"]["best_score"], training_score)
        json.dumps(result, allow_nan=False)


if __name__ == "__main__":
    unittest.main()
