"""Local-CSV integration and serialization checks for the user entry points."""

import contextlib
import csv
import io
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

from trading.cli import main, read_parameters
from trading.data import INTERVAL_MS
from trading.simulator import SimulationConfig


class CLITests(unittest.TestCase):
    @unittest.skipUnless(importlib.util.find_spec("matplotlib"), "matplotlib is an optional plotting dependency")
    def test_local_fsm_plot_and_baseline_plots_keep_simulation_metadata(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "local.csv"
            count = 1344 + 4 * 96
            close = 100 + 10 * np.sin(np.arange(count) / 18)
            with source.open("w", newline="") as stream:
                writer = csv.writer(stream)
                writer.writerow(["open_time", "open", "high", "low", "close", "volume"])
                for index, price in enumerate(close):
                    writer.writerow([index * INTERVAL_MS, price, price + 1, price - 1, price, 1])
            shared = ["--data", str(source), "--window-days", "1", "--step-days", "1", "--test-windows", "1"]
            figure = Path(directory) / "fsm.png"
            baseline_output = Path(directory) / "baselines"
            with patch("urllib.request.urlopen", side_effect=AssertionError("Network forbidden")), contextlib.redirect_stdout(io.StringIO()):
                status = main(["plot", *shared, "--fsm", "--fast", "17", "--slow", "50",
                               "--window-id", "3", "--fee-rate", "0.001", "--output", str(figure)])
                self.assertEqual(status, 0)
                status = main(["baselines", *shared, "--plots", "--random-walk-runs", "4",
                               "--output", str(baseline_output)])
                self.assertEqual(status, 0)
            for png in (figure, baseline_output / "roi_by_window.png", baseline_output / "capital_by_test_window.png"):
                self.assertTrue(png.exists())
                self.assertEqual(png.read_bytes()[:8], b"\x89PNG\r\n\x1a\n")
                self.assertGreater(png.stat().st_size, 1000)
            sidecar = json.loads(figure.with_suffix(".json").read_text())
            self.assertEqual(sidecar["window"]["window_id"], 3)
            self.assertEqual(sidecar["window"]["split"], "test")
            self.assertEqual(sidecar["parameters"]["fast"], 17)
            self.assertEqual(sidecar["parameters"]["slow"], 50)
            self.assertEqual(sidecar["simulation_config"]["fee_rate"], 0.001)
            self.assertEqual(sidecar["source"]["path"], str(source.resolve()))
            self.assertEqual(len(sidecar["source"]["sha256"]), 64)
            self.assertIn("trades", sidecar)
            self.assertIn("transitions", sidecar)
            self.assertEqual(sidecar["trade_count"], len(sidecar["trades"]))
            evaluation = json.loads((baseline_output / "evaluation.json").read_text())
            self.assertEqual(len(evaluation["rows"]), 4)
            self.assertEqual(evaluation["summary"]["test"]["selected_2sma"]["count"], 1)

    def test_full_local_run_exports_reproducible_artifacts_and_can_be_reused(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "local.csv"
            output = Path(directory) / "result"
            count = 1344 + 4 * 96
            close = 100 + 10 * np.sin(np.arange(count) / 18)
            with source.open("w", newline="") as stream:
                writer = csv.writer(stream)
                writer.writerow(["open_time", "open", "high", "low", "close", "volume"])
                for i, price in enumerate(close):
                    writer.writerow([i * INTERVAL_MS, price, price + 1, price - 1, price, 1])
            shared = ["--data", str(source), "--window-days", "1", "--step-days", "1", "--test-windows", "1"]
            with patch("urllib.request.urlopen", side_effect=AssertionError("Network forbidden")), contextlib.redirect_stdout(io.StringIO()):
                status = main(["run", *shared, "--output", str(output), "--population", "4",
                               "--iterations", "2", "--learning-interval", "1",
                               "--random-walk-runs", "4", "--fee-rate", "0.001", "--save-equity"])
            self.assertEqual(status, 0)
            expected = {"experiment.json", "optimizer.json", "parameters.json", "windows.csv",
                        "evaluation.json", "comparison.csv", "trades.csv", "equity.csv"}
            self.assertEqual({file.name for file in output.iterdir()}, expected)
            metadata = json.loads((output / "experiment.json").read_text())
            self.assertEqual(metadata["window_counts"], {"train": 3, "test": 1, "purged": 0})
            self.assertEqual(metadata["simulation_config"]["fee_rate"], 0.001)
            self.assertEqual(len(metadata["source"]["sha256"]), 64)
            parameters = read_parameters(output / "parameters.json")
            self.assertLess(parameters.fast, parameters.slow)
            optimizer = json.loads((output / "optimizer.json").read_text())
            self.assertGreater(optimizer["evaluations"], 0)
            json.dumps(optimizer, allow_nan=False)
            with (output / "comparison.csv").open(newline="") as stream:
                comparison = list(csv.DictReader(stream))
            self.assertEqual(len(comparison), 4)
            self.assertEqual(comparison[-1]["split"], "test")
            # Saved sizing/cost settings are inherited unless explicitly overridden.
            simulation_path = Path(directory) / "simulation.json"
            with contextlib.redirect_stdout(io.StringIO()):
                status = main(["simulate", *shared, "--parameters", str(output / "parameters.json"),
                               "--window-id", "3", "--output", str(simulation_path)])
            self.assertEqual(status, 0)
            simulation = json.loads(simulation_path.read_text())
            self.assertEqual(simulation["simulation_config"]["fee_rate"], 0.001)
            self.assertAlmostEqual(simulation["capital_factor"], float(comparison[-1]["selected_2sma"]))
            with contextlib.redirect_stdout(io.StringIO()):
                main(["simulate", *shared, "--parameters", str(output / "parameters.json"),
                      "--window-id", "3", "--output", str(simulation_path), "--fee-rate", "0"])
            self.assertEqual(json.loads(simulation_path.read_text())["simulation_config"]["fee_rate"], 0)

    def test_missing_csv_returns_error_and_never_downloads(self):
        with tempfile.TemporaryDirectory() as directory, patch("urllib.request.urlopen", side_effect=AssertionError("Network forbidden")), contextlib.redirect_stderr(io.StringIO()):
            output = Path(directory) / "output.json"
            self.assertEqual(main(["audit", "--data", str(Path(directory) / "missing.csv"), "--output", str(output)]), 2)
            self.assertFalse(output.exists())

    def test_simulation_setting_defaults(self):
        from trading.cli import _simulation_config, parser
        args = parser().parse_args(["simulate"])
        self.assertEqual(_simulation_config(args), SimulationConfig())


if __name__ == "__main__":
    unittest.main()
