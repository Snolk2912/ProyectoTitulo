"""Determinism, real evaluation accounting, and LB² adaptation tests."""

import json
import unittest

import numpy as np

from trading.lb2 import LB2Config, SearchSpace, _learn_probabilities, optimize
from trading.simulator import StrategyParameters


class SearchSpaceTests(unittest.TestCase):
    def test_decode_repairs_domain_and_integer_constraint(self):
        space = SearchSpace()
        vectors = [np.zeros(6), np.ones(6), np.array([2, -1, 3, -2, -4, 8])]
        vectors.extend(np.random.default_rng(12).uniform(-2, 2, size=(100, 6)))
        for vector in vectors:
            parameters = space.decode(vector)
            self.assertIsInstance(parameters.fast, int)
            self.assertLess(parameters.fast, parameters.slow)
            self.assertLessEqual(space.fast_min, parameters.fast)
            self.assertLessEqual(parameters.fast, space.fast_max)
            self.assertLessEqual(space.slow_min, parameters.slow)
            self.assertLessEqual(parameters.slow, space.slow_max)
            self.assertGreater(parameters.alpha_long, 0)
            self.assertLess(parameters.alpha_long, 1)
            self.assertGreater(parameters.alpha_short, 1)
            self.assertGreater(parameters.beta_long, 1)
            self.assertGreater(parameters.beta_short, 0)
            self.assertLess(parameters.beta_short, 1)
            np.testing.assert_allclose(space.repair(space.repair(vector)), space.repair(vector))

    def test_custom_domains_and_encode_roundtrip(self):
        space = SearchSpace(fast_min=12, fast_max=15, slow_min=10, slow_max=14)
        p = space.decode([1, 0, 0.2, 0.3, 0.4, 0.5])
        self.assertEqual((p.fast, p.slow), (12, 13))
        q = space.decode(space.encode(p))
        self.assertEqual((p.fast, p.slow), (q.fast, q.slow))
        np.testing.assert_allclose(space.encode(p), space.encode(q))

    def test_invalid_search_space_and_vector(self):
        for arguments in (
            {"fast_min": 20, "slow_max": 19}, {"fast_min": 1.2},
            {"fast_min": 1}, {"fast_max": 1344}, {"slow_min": 9}, {"slow_max": 1345},
            {"alpha_long_min": 0.89}, {"alpha_short_max": 1.11},
            {"alpha_long_min": 1}, {"alpha_short_max": 1},
            {"beta_long_min": 0.9}, {"beta_short_max": 1},
            {"beta_long_max": float("inf")},
        ):
            with self.assertRaises(ValueError):
                SearchSpace(**arguments)
        for vector in ([0] * 5, [0, 0, np.nan, 0, 0, 0]):
            with self.assertRaises(ValueError):
                SearchSpace().decode(vector)
        with self.assertRaises(ValueError):
            SearchSpace(fast_max=5).encode(StrategyParameters(6, 10, 0.95, 1.05, 2, 0.5))


class LearningTests(unittest.TestCase):
    def test_six_model_policy_uses_max_and_extrapolates_iteration(self):
        records = []
        for scheme in (1, 2, 3):
            for iteration in (1, 3, 6):
                records.append({"scheme": scheme, "iteration": iteration, "score": iteration * scheme})
                # A poorer observation from the same iteration must not alter the best.
                records.append({"scheme": scheme, "iteration": iteration, "score": -20})
        probs, trace = _learn_probabilities(records, 10, LB2Config(learning_interval=5))
        self.assertEqual(trace["winner"], 3)
        np.testing.assert_allclose(probs, [0.2, 0.2, 0.6])
        self.assertEqual([model["observations"] for model in trace["models"]], [3, 3, 3])
        np.testing.assert_allclose([model["prediction"] for model in trace["models"]], [15, 30, 45])

    def test_insufficient_data_and_ties_reset_uniform(self):
        config = LB2Config()
        probs, trace = _learn_probabilities([], 20, config)
        np.testing.assert_allclose(probs, [1 / 3] * 3)
        self.assertIsNone(trace["winner"])
        records = [
            {"scheme": scheme, "iteration": iteration, "score": 2.0}
            for scheme in (1, 2, 3) for iteration in (1, 2)
        ]
        probs, trace = _learn_probabilities(records, 20, config)
        np.testing.assert_allclose(probs, [1 / 3] * 3)
        self.assertEqual(trace["reason"], "tied_predictions")


class OptimizerTests(unittest.TestCase):
    def setUp(self):
        self.space = SearchSpace(fast_min=2, fast_max=8, slow_min=10, slow_max=20)
        self.target = StrategyParameters(4, 14, 0.95, 1.04, 1.5, 0.6)
        self.target_vector = self.space.encode(self.target)

    def objective(self, parameters):
        return -float(np.sum((self.space.encode(parameters) - self.target_vector) ** 2))

    def test_optimization_is_deterministic_and_really_learns(self):
        config = LB2Config(population_size=12, iterations=40, learning_interval=8, seed=6)
        first = optimize(self.objective, self.space, config)
        second = optimize(self.objective, self.space, config)
        self.assertEqual(first.to_dict(), second.to_dict())
        self.assertEqual(len(first.history), config.iterations + 1)
        self.assertGreater(first.best_score, first.history[0]["best_score"])
        self.assertTrue(np.all(np.diff([h["best_score"] for h in first.history]) >= 0))
        self.assertAlmostEqual(first.best_score, self.objective(first.best_parameters))
        self.assertEqual(len(first.learning_updates), 5)
        self.assertTrue(any(
            update[phase]["winner"] is not None
            for update in first.learning_updates
            for phase in ("intensification", "diversification")
        ))
        for update in first.learning_updates:
            for phase in ("intensification", "diversification"):
                self.assertEqual(len(update[phase]["models"]), 3)
                self.assertAlmostEqual(sum(update[phase]["probabilities"]), 1)
        counts = {
            operator: sum(h["operator_attempts"][operator] for h in first.history[1:])
            for operator in ("attack", "search", "encircle", "hunt")
        }
        self.assertTrue(all(count > 0 for count in counts.values()))
        json.dumps(first.to_dict(), allow_nan=False)

    def test_elite_initial_optimum_is_preserved_and_accounting_is_exact(self):
        evaluated = set()

        def objective(parameters):
            key = tuple(vars(parameters).values())
            self.assertNotIn(key, evaluated, "Exact decoded parameters must be memoized")
            evaluated.add(key)
            return self.objective(parameters)

        config = LB2Config(population_size=8, iterations=12, learning_interval=4)
        result = optimize(objective, self.space, config, self.target)
        self.assertAlmostEqual(result.best_score, 0.0, places=14)
        self.assertEqual(len(evaluated), result.evaluations)
        self.assertGreater(result.cache_hits, 0)
        self.assertEqual(
            result.movement_attempts + config.population_size,
            result.evaluations + result.cache_hits,
        )
        minimum = config.iterations * config.population_size * 2
        self.assertGreaterEqual(result.movement_attempts, minimum)
        self.assertLessEqual(result.movement_attempts, minimum * 3)

    def test_invalid_config_and_objective(self):
        for arguments in (
            {"population_size": 1}, {"iterations": 0}, {"learning_interval": 0},
            {"seed": -1}, {"winner_probability": 0.2}, {"winner_probability": np.nan},
        ):
            with self.assertRaises(ValueError):
                LB2Config(**arguments)
        for value in (np.nan, np.inf, True, "1.2"):
            with self.assertRaises(ValueError):
                optimize(lambda parameters: value, self.space, LB2Config(population_size=2, iterations=1))
        with self.assertRaises(ValueError):
            optimize(None, self.space, LB2Config(population_size=2, iterations=1))

    def test_initial_infeasible_population_keeps_exploring_and_json_is_strict(self):
        config = LB2Config(population_size=6, iterations=8, learning_interval=2, seed=9)
        rng = np.random.default_rng(config.seed)
        initially_infeasible = {
            tuple(vars(self.space.decode(vector)).values())
            for vector in rng.random((config.population_size, 6))
        }

        def objective(parameters):
            if tuple(vars(parameters).values()) in initially_infeasible:
                return -np.inf
            return self.objective(parameters)

        result = optimize(objective, self.space, config)
        self.assertIsNone(result.history[0]["best_score"])
        self.assertTrue(np.isfinite(result.best_score))
        self.assertGreater(result.evaluations, config.population_size)
        recovered = [
            record for records in result.improvement_records.values()
            for record in records if record["improvement"] is None
        ]
        self.assertTrue(recovered)
        json.dumps(result.to_dict(), allow_nan=False)

    def test_all_infeasible_consumes_full_iteration_budget_then_reports_failure(self):
        config = LB2Config(population_size=4, iterations=5, learning_interval=2)
        calls = 0

        def objective(parameters):
            nonlocal calls
            calls += 1
            return -np.inf

        with self.assertRaisesRegex(ValueError, "No feasible candidate after 5 iterations"):
            optimize(objective, self.space, config)
        self.assertGreater(calls, config.population_size * config.iterations)


if __name__ == "__main__":
    unittest.main()
