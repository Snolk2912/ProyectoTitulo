"""Importing legacy entry points must never read data, write files or use a network."""

import builtins
from contextlib import ExitStack
import importlib.util
import os
from pathlib import Path
import socket
import sys
import tempfile
from types import ModuleType
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = [
    "(1)download_binance_15m_60d.py", "(2)audit_data.py", "(3)build_windows.py",
    "(6)step1_single_sma_validation.py", "(7)step2_double_sma_validation.py",
    "(9)step3_fsm_2sma_discrete.py", "(10)step4_risk_management_pnl.py", "(11)baselines.py",
]


class ImportSafetyTests(unittest.TestCase):
    def test_all_numbered_scripts_import_without_side_effects(self):
        forbidden = mock.Mock(side_effect=AssertionError("Import attempted filesystem mutation or network access"))
        requests_stub = ModuleType("requests")
        for name in ("get", "post", "put", "delete", "request", "Session"):
            setattr(requests_stub, name, forbidden)
        real_open = builtins.open

        def read_only_open(file, mode="r", *args, **kwargs):
            if any(flag in mode for flag in "wax+"):
                raise AssertionError("Import attempted to write a file")
            return real_open(file, mode, *args, **kwargs)

        previous_cwd = Path.cwd()
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            temporary_path = Path(temporary)
            before = set(temporary_path.rglob("*"))
            os.chdir(temporary_path)
            stack.callback(os.chdir, previous_cwd)
            stack.enter_context(mock.patch.object(sys, "dont_write_bytecode", True))
            stack.enter_context(mock.patch.dict(sys.modules, {"requests": requests_stub}))
            stack.enter_context(mock.patch("urllib.request.urlopen", forbidden))
            stack.enter_context(mock.patch.object(socket.socket, "connect", forbidden))
            stack.enter_context(mock.patch.object(socket, "create_connection", forbidden))
            stack.enter_context(mock.patch.object(Path, "mkdir", forbidden))
            stack.enter_context(mock.patch.object(Path, "write_text", forbidden))
            stack.enter_context(mock.patch.object(Path, "write_bytes", forbidden))
            stack.enter_context(mock.patch.object(os, "mkdir", forbidden))
            stack.enter_context(mock.patch.object(builtins, "open", read_only_open))
            for number, filename in enumerate(SCRIPTS):
                with self.subTest(script=filename):
                    spec = importlib.util.spec_from_file_location(f"legacy_import_safety_{number}", ROOT / filename)
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
            self.assertEqual(set(temporary_path.rglob("*")), before)
            forbidden.assert_not_called()


if __name__ == "__main__":
    unittest.main()
