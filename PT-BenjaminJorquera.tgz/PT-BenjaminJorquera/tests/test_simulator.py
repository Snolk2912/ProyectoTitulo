"""Physical execution, linear-contract accounting and Figure 3 FSM tests."""

import unittest

import numpy as np

from trading.data import INTERVAL_MS, MarketData
from trading.simulator import (
    IndicatorCache, LONG_OPEN, SHORT_OPEN, WAITING_LONG, WAITING_SHORT,
    SimulationConfig, StrategyParameters, exit_decision, regime_of, simulate,
    simulate_buy_and_hold,
)


def market(closes, opens=None, highs=None, lows=None):
    closes = np.asarray(closes, dtype=np.float64)
    opens = closes.copy() if opens is None else np.asarray(opens, dtype=np.float64)
    highs = np.maximum(opens, closes) if highs is None else np.asarray(highs, dtype=np.float64)
    lows = np.minimum(opens, closes) if lows is None else np.asarray(lows, dtype=np.float64)
    data = MarketData(np.arange(len(closes), dtype=np.int64) * INTERVAL_MS,
                      opens, highs, lows, closes, np.ones(len(closes)))
    data.validate()
    return data


HISTORY = [100.0] * 8 + [110.0, 120.0]
PARAMETERS = StrategyParameters(2, 10, 0.95, 1.05, 3.0, 0.50)
NO_COST = SimulationConfig(fee_rate=0)


class ExecutionTests(unittest.TestCase):
    def test_signal_at_close_fills_at_following_open_and_last_close_is_mandatory(self):
        data = market(HISTORY + [130.0], HISTORY + [125.0])
        result = simulate(data, PARAMETERS, NO_COST, start=9)
        self.assertEqual(result.trade_count, 1)
        trade = result.trades[0]
        self.assertEqual(trade.entry_price, 125.0)
        self.assertEqual(trade.signal_time, 10 * INTERVAL_MS)
        self.assertEqual(trade.entry_time, 10 * INTERVAL_MS)
        self.assertEqual(trade.exit_time, 11 * INTERVAL_MS)
        self.assertEqual(trade.exit_price, 130.0)
        self.assertEqual(trade.exit_reason, "end_of_window")
        self.assertAlmostEqual(result.final_capital, 130 / 125)
        self.assertAlmostEqual(result.equity_curve[-1]["equity"], result.final_capital)
        entry_signal = next(event for event in result.transitions if event["action"] == "entry_signal_long")
        self.assertEqual(entry_signal["time"], trade.signal_time)
        self.assertEqual(result.transitions[-1]["time"], trade.exit_time)
        self.assertEqual(result.final_state, WAITING_SHORT)

    def test_final_bar_entry_signal_cannot_fill_outside_window(self):
        data = market(HISTORY + [125.0])
        result = simulate(data, PARAMETERS, NO_COST, start=9, end=10)
        self.assertEqual(result.trade_count, 0)
        self.assertEqual(result.final_capital, 1.0)
        self.assertFalse(result.trades)

    def test_highs_before_or_during_entry_do_not_create_a_trailing_fill(self):
        data = market(HISTORY + [125.0, 120.0])
        extreme_highs = np.full(len(data), 1000.0)
        extreme_lows = np.full(len(data), 1.0)
        altered = market(data.close, data.open, extreme_highs, extreme_lows)
        regular = simulate(data, PARAMETERS, NO_COST, start=9)
        exaggerated = simulate(altered, PARAMETERS, NO_COST, start=9)
        self.assertEqual(regular.to_dict(), exaggerated.to_dict())
        self.assertEqual(regular.trades[0].exit_reason, "end_of_window")
        self.assertEqual(regular.trades[0].exit_price, 120.0)

    def test_stop_signal_fills_at_real_open_after_gap(self):
        data = market(HISTORY + [130.0, 120.0, 90.0],
                      HISTORY + [120.0, 130.0, 90.0])
        result = simulate(data, PARAMETERS, NO_COST, start=9)
        trade = result.trades[0]
        self.assertEqual(trade.entry_price, 120.0)
        self.assertEqual(trade.exit_reason, "trailing_stop_long")
        self.assertEqual(trade.exit_price, 90.0)
        self.assertEqual(trade.exit_time, data.times[12])
        self.assertLessEqual(data.low[12], trade.exit_price)
        self.assertGreaterEqual(data.high[12], trade.exit_price)
        stop_signal = next(event for event in result.transitions if event["action"] == "exit_signal")
        self.assertEqual(stop_signal["time"], data.times[11] + INTERVAL_MS)
        self.assertAlmostEqual(result.final_capital, 0.75)

    def test_short_100_to_90_has_ten_percent_linear_profit(self):
        # First take profit on the initial long. A negative SMA regime then
        # creates the short, whose evaluated prices are precisely 100 -> 90.
        data = market(HISTORY + [135.0, 70.0, 95.0, 90.0],
                      HISTORY + [120.0, 132.0, 100.0, 95.0])
        parameters = StrategyParameters(2, 10, 0.95, 1.05, 1.10, 0.50)
        result = simulate(data, parameters, NO_COST, start=9)
        self.assertEqual([trade.side for trade in result.trades], ["long", "short"])
        short = result.trades[1]
        self.assertEqual(short.entry_price, 100.0)
        self.assertEqual(short.exit_price, 90.0)
        self.assertAlmostEqual(short.gross_pnl / short.capital_before, 0.10)
        self.assertAlmostEqual(short.capital_after / short.capital_before, 1.10)
        self.assertAlmostEqual(result.final_capital, 1.21)
        self.assertEqual(short.exit_reason, "end_of_window")
        self.assertEqual(result.final_state, WAITING_LONG)

    def test_commissions_use_each_actual_executed_notional(self):
        data = market(HISTORY + [132.0], HISTORY + [120.0])
        config = SimulationConfig(initial_capital=1000.0, fee_rate=0.001)
        result = simulate(data, PARAMETERS, config, start=9)
        trade = result.trades[0]
        self.assertAlmostEqual(trade.quantity, 1000 / 120)
        self.assertAlmostEqual(trade.fee_open, 1.0)
        self.assertAlmostEqual(trade.fee_close, 1.1)
        self.assertAlmostEqual(trade.gross_pnl, 100.0)
        self.assertAlmostEqual(trade.net_pnl, 97.9)
        self.assertAlmostEqual(result.final_capital, 1097.9)
        hold = simulate_buy_and_hold(data, config, start=10)
        self.assertAlmostEqual(hold.final_capital, result.final_capital)
        self.assertAlmostEqual(hold.trades[0].fee_close, trade.fee_close)
        self.assertEqual(hold.trades[0].exit_time, data.times[-1] + INTERVAL_MS)

    def test_slippage_is_adverse_on_both_sides_and_fees_follow_fills(self):
        data = market(HISTORY + [132.0], HISTORY + [120.0])
        config = SimulationConfig(initial_capital=1000.0, fee_rate=0.001, slippage_bps=100)
        trade = simulate(data, PARAMETERS, config, start=9).trades[0]
        self.assertAlmostEqual(trade.entry_price, 121.2)
        self.assertAlmostEqual(trade.exit_price, 130.68)
        self.assertAlmostEqual(trade.quantity, 1000 / 121.2)
        self.assertAlmostEqual(trade.fee_open, trade.quantity * trade.entry_price * config.fee_rate)
        self.assertAlmostEqual(trade.fee_close, trade.quantity * trade.exit_price * config.fee_rate)
        self.assertAlmostEqual(trade.net_pnl, trade.gross_pnl - trade.fee_open - trade.fee_close)

    def test_bankruptcy_at_close_caps_account_at_zero(self):
        data = market(HISTORY + [40.0, 50.0], HISTORY + [120.0, 50.0])
        config = SimulationConfig(leverage=2.0, fee_rate=0)
        result = simulate(data, PARAMETERS, config, start=9)
        self.assertTrue(result.bankrupt)
        self.assertEqual(result.final_capital, 0)
        self.assertEqual(result.trade_count, 1)
        self.assertEqual(result.trades[0].exit_reason, "bankruptcy")
        self.assertEqual(result.trades[0].exit_time, data.times[10] + INTERVAL_MS)
        self.assertEqual(result.equity_curve[-1]["equity"], 0)
        self.assertEqual(result.final_state, WAITING_LONG)

    def test_bankruptcy_gap_executes_at_open_not_historical_stop(self):
        data = market(HISTORY + [125.0, 20.0, 30.0], HISTORY + [120.0, 20.0, 30.0])
        result = simulate(data, PARAMETERS, SimulationConfig(leverage=2.0, fee_rate=0), start=9)
        self.assertTrue(result.bankrupt)
        self.assertEqual(result.trade_count, 1)
        self.assertEqual(result.trades[0].exit_price, 20.0)
        self.assertEqual(result.trades[0].exit_time, data.times[11])

    def test_entry_slippage_can_exhaust_equity_at_open_before_price_recovers(self):
        data = market(HISTORY + [150.0], HISTORY + [120.0])
        config = SimulationConfig(leverage=20.0, fee_rate=0, slippage_bps=1000)
        result = simulate(data, PARAMETERS, config, start=9)
        hold = simulate_buy_and_hold(data, config, start=10)
        # Entry at 132 with quantity 20/132 immediately has negative marked
        # equity at the observed open 120; the later close 150 cannot rescue it.
        self.assertTrue(result.bankrupt)
        self.assertEqual(result.final_capital, 0)
        self.assertEqual(result.trades[0].exit_reason, "bankruptcy")
        self.assertEqual(result.trades[0].exit_time, data.times[10])
        self.assertEqual(result.trades[0].exit_price, 108.0)
        self.assertEqual(result.final_capital, hold.final_capital)


class Figure3Tests(unittest.TestCase):
    def test_all_stop_regime_destinations(self):
        cases = [(1, 90.0, -1, "trailing_stop_long", WAITING_LONG),
                 (1, 90.0, 1, "trailing_stop_long", WAITING_SHORT),
                 (-1, 110.0, 1, "trailing_stop_short", WAITING_SHORT),
                 (-1, 110.0, -1, "trailing_stop_short", WAITING_LONG)]
        for side, price, regime, reason, destination in cases:
            with self.subTest(side=side, regime=regime):
                self.assertEqual(exit_decision(side, price, 100.0, 100.0, regime, PARAMETERS),
                                 (reason, destination))

    def test_profit_switches_side_including_tied_regime(self):
        for regime in (-1, 0, 1):
            with self.subTest(regime=regime):
                self.assertEqual(exit_decision(1, 301.0, 301.0, 100.0, regime, PARAMETERS),
                                 ("take_profit_long", WAITING_SHORT))
                self.assertEqual(exit_decision(-1, 49.0, 49.0, 100.0, regime, PARAMETERS),
                                 ("take_profit_short", WAITING_LONG))

    def test_strict_thresholds_and_sma_ties_do_not_trigger_stop(self):
        cases = [(1, 95.0, 100.0, 1), (-1, 105.0, 100.0, -1),
                 (1, 300.0, 300.0, 1), (-1, 50.0, 50.0, -1),
                 (1, 90.0, 100.0, 0), (-1, 110.0, 100.0, 0)]
        for side, price, extreme, regime in cases:
            with self.subTest(side=side, price=price, regime=regime):
                self.assertIsNone(exit_decision(side, price, extreme, 100.0, regime, PARAMETERS))
        self.assertEqual(regime_of(100.0, 100.0), 0)
        self.assertEqual(regime_of(100.0 + 5e-11, 100.0), 0)
        self.assertEqual(regime_of(100.0 + 1e-8, 100.0), 1)
        self.assertEqual(regime_of(100.0 - 1e-8, 100.0), -1)

    def test_opened_state_transitions_follow_executed_side(self):
        data = market(HISTORY + [135.0, 70.0, 95.0, 90.0],
                      HISTORY + [120.0, 132.0, 100.0, 95.0])
        parameters = StrategyParameters(2, 10, 0.95, 1.05, 1.10, 0.50)
        result = simulate(data, parameters, NO_COST, start=9)
        opening_states = [event["new_state"] for event in result.transitions if event["action"] == "open"]
        self.assertEqual(opening_states, [LONG_OPEN, SHORT_OPEN])


class CausalityAndCacheTests(unittest.TestCase):
    def test_future_prices_cannot_change_completed_prefix_experiment(self):
        prefix_closes = HISTORY + [130.0, 120.0, 110.0, 105.0]
        prefix_opens = HISTORY + [120.0, 130.0, 110.0, 105.0]
        ordinary = market(prefix_closes + [100.0] * 20, prefix_opens + [100.0] * 20)
        extreme = market(prefix_closes + [10000.0] * 20, prefix_opens + [10000.0] * 20)
        first = simulate(ordinary, PARAMETERS, NO_COST, start=9, end=len(prefix_closes))
        second = simulate(extreme, PARAMETERS, NO_COST, start=9, end=len(prefix_closes))
        self.assertEqual(first.to_dict(), second.to_dict())

    def test_recording_and_cached_modes_preserve_economic_result(self):
        data = market(HISTORY + [130.0, 120.0, 90.0], HISTORY + [120.0, 130.0, 90.0])
        detailed = simulate(data, PARAMETERS, start=9)
        cache = IndicatorCache(data)
        compact = simulate(data, PARAMETERS, start=9, record_trades=False, indicator_cache=cache)
        cached_detail = simulate(data, PARAMETERS, start=9, indicator_cache=cache)
        for field in ("final_capital", "trade_count", "bankrupt", "final_state", "capital_factor", "log_return"):
            self.assertEqual(getattr(detailed, field), getattr(compact, field))
        self.assertFalse(compact.trades)
        self.assertFalse(compact.transitions)
        self.assertFalse(compact.equity_curve)
        self.assertEqual(detailed.to_dict(), cached_detail.to_dict())
        other_data = market(data.close, data.open)
        with self.assertRaisesRegex(ValueError, "another dataset"):
            simulate(other_data, PARAMETERS, indicator_cache=cache)

    def test_cache_matches_direct_causal_means_and_has_bounded_lru(self):
        data = market(HISTORY + [130.0, 120.0, 90.0])
        cache = IndicatorCache(data, max_periods=2)
        short = cache.sma(2)
        self.assertTrue(np.isnan(short[0]))
        for index in range(1, len(data)):
            self.assertAlmostEqual(short[index], np.mean(data.close[index - 1:index + 1]))
        self.assertFalse(short.flags.writeable)
        cache.sma(10)
        self.assertIs(cache.sma(2), short)  # refresh the 2-period LRU entry
        cache.sma(3)
        self.assertEqual(list(cache.cache), [2, 3])
        self.assertEqual(len(cache.cache), 2)
        self.assertTrue(np.all(np.isnan(cache.sma(100))))

    def test_insufficient_history_and_invalid_window_are_rejected(self):
        data = market(HISTORY + [130.0])
        for bounds in ({"start": 8}, {"start": 9, "end": 9}, {"start": 9, "end": 12}):
            with self.subTest(bounds=bounds), self.assertRaises(ValueError):
                simulate(data, PARAMETERS, **bounds)


if __name__ == "__main__":
    unittest.main()
