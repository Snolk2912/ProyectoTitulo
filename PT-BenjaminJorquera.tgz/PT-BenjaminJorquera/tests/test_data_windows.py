"""Behavioral checks for source-data integrity and temporal holdout boundaries."""

import csv
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

from trading.data import INTERVAL_MS, MarketData, iso_utc, load_csv, timestamp_ms
from trading.windows import build_windows, write_manifest


def series(count: int, start: int = 0) -> MarketData:
    close = np.linspace(100.0, 110.0, count)
    return MarketData(start + np.arange(count, dtype=np.int64) * INTERVAL_MS,
                      close, close + 1, close - 1, close, np.ones(count))


class DataTests(unittest.TestCase):
    def test_timezone_roundtrip_and_dates(self):
        value = timestamp_ms("2020-01-01T03:00:00.123+03:00")
        self.assertEqual(iso_utc(value), "2020-01-01T00:00:00.123Z")
        self.assertEqual(timestamp_ms(iso_utc(value)), value)
        self.assertEqual(timestamp_ms(str(value)), value)
        self.assertEqual(timestamp_ms("2020-01-01"), timestamp_ms("2020-01-01T00:00:00Z"))
        self.assertEqual(iso_utc(-1), "1969-12-31T23:59:59.999Z")
        for invalid in ("2020-01-01T00:00:00", "2020-01-01T00:00:00.000001Z", "not-time", True):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                timestamp_ms(invalid)

    def test_rejects_duplicate_unsorted_missing_and_offgrid_times(self):
        for times in ([0, 0, INTERVAL_MS], [0, 2 * INTERVAL_MS, INTERVAL_MS],
                      [0, INTERVAL_MS, 3 * INTERVAL_MS], [1, INTERVAL_MS + 1, 2 * INTERVAL_MS + 1]):
            data = series(3)
            data.times = np.asarray(times, dtype=np.int64)
            with self.subTest(times=times), self.assertRaises(ValueError):
                data.validate()

    def test_rejects_bad_ohlcv_and_dimensions(self):
        mutations = [lambda d: setattr(d, "high", d.close - 1),
                     lambda d: setattr(d, "low", d.close + 1),
                     lambda d: setattr(d, "open", np.zeros(3)),
                     lambda d: setattr(d, "volume", np.array([1., -1., 1.])),
                     lambda d: setattr(d, "close", np.array([1., np.nan, 1.])),
                     lambda d: setattr(d, "volume", np.ones(2)),
                     lambda d: setattr(d, "high", np.ones((3, 1))),
                     lambda d: setattr(d, "interval_ms", 60000)]
        for mutate in mutations:
            data = series(3)
            mutate(data)
            with self.assertRaises(ValueError):
                data.validate()
        with self.assertRaises(ValueError):
            series(0).validate()

    def test_slice_uses_half_open_indices_and_preserves_data(self):
        data = series(5)
        selected = data.slice(1, 3)
        selected.validate()
        self.assertEqual(len(selected), 2)
        np.testing.assert_array_equal(selected.times, data.times[1:3])
        for invalid in ((-1, 3), (0, 6), (3, 2), (0.0, 3)):
            with self.subTest(bounds=invalid), self.assertRaises(ValueError):
                data.slice(*invalid)

    def test_csv_loads_original_and_rejects_duplicate_window_rows(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "data.csv"
            fields = ["open_time", "open", "high", "low", "close", "volume"]

            def write_rows(rows, headers=fields):
                with path.open("w", newline="") as output:
                    writer = csv.writer(output)
                    writer.writerow(headers)
                    writer.writerows(rows)

            valid = [["1970-01-01T00:00:00Z", 100, 101, 99, 100, 10],
                     ["900000", 100, 101, 99, 100, 0]]
            write_rows(valid)
            self.assertEqual(len(load_csv(path)), 2)
            write_rows([valid[0], valid[0]])
            with self.assertRaisesRegex(ValueError, "unique"):
                load_csv(path)
            write_rows([valid[0] + [0]], fields + ["window_id"])
            with self.assertRaisesRegex(ValueError, "original processed"):
                load_csv(path)
            write_rows([["1970-01-01T00:00:00", 100, 101, 99, 100, 10]])
            with self.assertRaisesRegex(ValueError, "row 2"):
                load_csv(path)


class WindowTests(unittest.TestCase):
    def test_purges_boundary_overlap_retaining_original_ids(self):
        warmup = 4
        data = series(9 * 96 + warmup)
        windows = build_windows(data, window_days=2, step_days=1, n_test=2, warmup_bars=warmup)
        train = [window for window in windows if window.split == "train"]
        test = [window for window in windows if window.split == "test"]
        purged = [window for window in windows if window.split == "purged"]
        self.assertEqual(len(windows), 8)
        self.assertEqual(len(test), 2)
        self.assertEqual(len(purged), 1)
        self.assertEqual(purged[0].window_id, 5)
        self.assertTrue(all(window.end_ms <= test[0].start_ms for window in train))
        train_bars = set().union(*(set(range(window.start_index, window.end_index)) for window in train))
        test_bars = set().union(*(set(range(window.start_index, window.end_index)) for window in test))
        self.assertFalse(train_bars & test_bars)
        self.assertEqual(windows[0].start_index, warmup)
        self.assertTrue(all(window.row_count == 192 for window in windows))
        # A common warmup is available before every evaluation, and its bars
        # remain outside the corresponding evaluation slice.
        for window in windows:
            history = data.slice(window.start_index - warmup, window.start_index)
            self.assertEqual(len(history), warmup)
            self.assertLess(history.times[-1], window.start_ms)

    def test_nonoverlap_split_and_trailing_partial(self):
        data = series(3 * 96 + 4 + 17)
        windows = build_windows(data, window_days=1, step_days=1, n_test=1, warmup_bars=4)
        self.assertEqual([window.split for window in windows], ["train", "train", "test"])
        self.assertEqual(windows[-1].end_index, len(data) - 17)

    def test_explicit_dates_do_not_shift_and_need_warmup_and_coverage(self):
        data = series(5 * 96)
        start = INTERVAL_MS * 12
        end = INTERVAL_MS * (12 + 3 * 96)
        windows = build_windows(data, 1, 1, 1, 4, start, end)
        self.assertEqual(windows[0].start_ms, start)
        self.assertEqual(windows[-1].end_ms, end)
        for options in ({"start_ms": 0}, {"start_ms": INTERVAL_MS + 1},
                        {"start_ms": -INTERVAL_MS}, {"end_ms": len(data) * INTERVAL_MS + INTERVAL_MS}):
            with self.subTest(options=options), self.assertRaises(ValueError):
                build_windows(data, 1, 1, 1, 4, **options)

    def test_rejects_config_insufficient_train_and_noncontiguous_data(self):
        data = series(3 * 96)
        for options in ({"window_days": 0}, {"step_days": -1}, {"n_test": 0},
                        {"n_test": 1.5}, {"warmup_bars": -1}, {"window_days": 0.001}):
            with self.subTest(options=options), self.assertRaises(ValueError):
                build_windows(data, **options)
        # Exactly two overlapping windows: assigning one to test requires
        # purging the other, so there is no independent training sample.
        with self.assertRaisesRegex(ValueError, "leaves no train"):
            build_windows(data, 2, 1, 1, 0)
        data.times[100:] += INTERVAL_MS
        with self.assertRaisesRegex(ValueError, "no gaps"):
            build_windows(data, 1, 1, 1, 0)

    def test_manifests_export_metadata_without_repeating_price_rows(self):
        windows = build_windows(series(3 * 96), 1, 1, 1, 0)
        with tempfile.TemporaryDirectory() as temporary:
            json_path = Path(temporary) / "manifest.json"
            csv_path = Path(temporary) / "manifest.csv"
            write_manifest(windows, json_path)
            write_manifest(windows, csv_path)
            records = json.loads(json_path.read_text())
            self.assertEqual(len(records), 3)
            self.assertEqual(records[-1]["split"], "test")
            self.assertNotIn("close", records[0])
            with csv_path.open(newline="") as source:
                self.assertEqual(len(list(csv.DictReader(source))), 3)


if __name__ == "__main__":
    unittest.main()
