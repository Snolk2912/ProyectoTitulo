# Especificación de la réplica: 2-SMA y LB²

Esta especificación fija un experimento reproducible con datos locales y un simulador causal. Es una adaptación explícita de los dos artículos incluidos en el repositorio; no se presenta como una reproducción numérica exacta. No se descargan datos ni se consulta Binance al auditar, simular u optimizar. El programa de descarga histórico queda fuera de este flujo.

Fuentes locales:

- [Artículo de trading, Mathematics 13, 2629 (2025)](../mathematics-13-02629.pdf): secciones 5–7, figura 3 y tablas 3–4.
- [Learning-based Linear Balancer, Mathematics 9, 1976 (2021)](../mathematics-09-01976-v2%20%281%29.pdf): secciones 3.1–3.4, algoritmos 1–2 y tablas 1–2.

El nombre usado aquí es **LB²**, también escrito `LB2`. La referencia a «LV2» del README se interpreta como este algoritmo.

## 1. Decisiones que los artículos no permiten resolver de forma única

| Punto | Información publicada | Decisión de esta implementación |
|---|---|---|
| Número de ventanas | 23 train y 8 test: 31 ventanas; también 34 experimentos repetidos. | Las ventanas dependen de la cobertura real del CSV. 34 es un número de ejecuciones, no una cantidad de ventanas. No se inventan fechas para alcanzar 31. |
| Fechas | El texto indica agosto de 2020–enero de 2022; la figura 5 indica enero de 2020–septiembre de 2022. | Se usan timestamps del archivo suministrado y se exporta el manifiesto de ventanas. |
| Función objetivo | Sección 5: beneficio acumulado y exclusión de retornos logarítmicos; sección 6: media logarítmica; sección 7: media geométrica. | Maximizar la media del logaritmo del capital final relativo en train. La exponencial se informa como factor geométrico. |
| Señales | La prosa describe cruces; la figura 3 muestra relaciones estrictas entre SMA. | FSM de la figura 3, con entradas por régimen `fast > slow` o `fast < slow`. |
| Observación del stop | El artículo modela precios de cierre; los códigos antiguos empleaban máximos/mínimos OHLC. | Observar cierres posteriores al fill; ejecutar decisiones en la siguiente apertura disponible. |
| Ejecución | No se especifica un calendario de señales/fills ni un modelo intravela. | Decisión al cierre `t`; ejecución en `open[t+1]`. Nunca se llena al umbral de stop. |
| Capital y costes | Se mencionan Binance Futures, apalancamiento y comisiones sin una definición completa. | Contrato lineal USDT, cantidad fija durante la posición, comisiones por notional en cada fill. |
| Límites de stop-win | Solo `beta_short < 1` y `beta_long > 1`. | Límites finitos de búsqueda elegidos y publicados en la sección 5. |
| Regresión de LB² | Se dice que `x` corresponde al esquema, pero se ajusta una regresión independiente por esquema; no queda definido un `x` variable dentro de cada grupo. | `x` es la iteración; `y` es el fitness personal alcanzado tras una mejora del esquema correspondiente. |
| Clúster SHO | `countnos(Ph, ..., Ph+M)` no define completamente la pertenencia. | Vecinos de la élite dentro de límites aleatorios por coordenada en el espacio normalizado. |
| Benchmark aleatorio | El artículo describe un Random Walk de precios, sin una política de inversión completa. | Modelo estocástico calibrado exclusivamente con train; se publica separadamente como benchmark sintético. No es Random Forest. |

Estas decisiones deben fijarse antes de evaluar test. Cambiarlas después de observar test constituye otro experimento y requiere otro resultado identificado como tal.

## 2. Datos, ventanas y separación temporal

### Entrada local

La entrada es un CSV original de velas OHLCV de 15 minutos con las columnas `open_time`, `open`, `high`, `low`, `close`, `volume`; se admiten columnas adicionales. No se admite como entrada un CSV de ventanas que repita observaciones. `open_time` acepta milisegundos enteros desde el epoch o texto ISO. Una fecha simple `YYYY-MM-DD` se interpreta como medianoche UTC; un datetime debe indicar su zona horaria. Se rechazan datetimes sin zona y precisión inferior al milisegundo. Se convierte el tiempo a UTC y se comprueba:

- timestamps ordenados, únicos, alineados al intervalo de 15 minutos y separados exactamente 900 segundos;
- OHLC numérico, finito y estrictamente positivo;
- volumen numérico, finito y no negativo;
- `low <= min(open, close) <= max(open, close) <= high`;
- suficiente cobertura para las ventanas y su historia anterior.

Los huecos, duplicados y velas incoherentes son errores. No se comprime el tiempo eliminando filas ni se rellenan precios de forma implícita. Una reparación de datos debe producir otro archivo y documentar su transformación.

### Construcción de ventanas

Cada evaluación dura **60 días = 5760 velas**, con inicio cada **30 días = 2880 velas**. Se usa el intervalo semiabierto `[inicio, fin)`: la última vela tiene timestamp `fin - 15 minutos`.

Por defecto se exige una historia común de **1344 velas anteriores**, suficiente para todo el rango admisible de SMA. Todos los candidatos se evalúan en las mismas 5760 velas; la historia sirve para indicadores y no produce operaciones, capital ni métricas. No se reinicia cada SMA descartando un warm-up distinto según el candidato.

Sin ancla explícita, el primer inicio evaluable es el timestamp de índice 1344 del archivo. Desde allí se avanza 30 días. Solo se aceptan ventanas completas; el remanente final no se evalúa. Un inicio explícito debe existir en la grilla y disponer de suficiente historia: no se desplaza automáticamente para hacerlo válido. El número efectivo depende del archivo; se registra en el manifiesto junto con sus fechas e índices. Duración, avance, historia y número de test son configurables; 60/30/1344/8 son los defaults, y un experimento modificado debe informar sus valores.

Las últimas **ocho** ventanas completas constituyen test. Entre las anteriores, se conservan en train solo las que cumplen `fin <= inicio_del_primer_test`. Se purga toda ventana train que invada el periodo evaluado de test. Debe quedar al menos una ventana train; de lo contrario, se rechaza la configuración. Los IDs comienzan en cero y se conservan al purgar: el manifiesto mantiene las ventanas excluidas con `split=purged`, sin renumerar las restantes.

Con avance de 30 días y longitud de 60 días, la ventana inmediatamente anterior al primer test suele ser purgada. El solapamiento entre ventanas de un mismo conjunto se conserva, pero esas observaciones no constituyen muestras estadísticamente independientes. Los precios anteriores a test pueden utilizarse como historia causal de las SMA de test; no se utilizan sus resultados para ajustar parámetros.

Para construir 31 ventanas de esta longitud y avance se requieren al menos `60 + 30 × 30 = 960` días de evaluación, además de la historia anterior. El rango agosto de 2020–enero de 2022 no alcanza esa cobertura. No se impone simultáneamente esa fecha y 31 ventanas.

Cada ventana inicia su cuenta con capital independiente de **1 USDT**. No se encadenan capitales entre ventanas solapadas: hacerlo invertiría simultáneamente el mismo capital en periodos compartidos y exageraría el significado de una curva compuesta.

## 3. Estrategia y calendario causal

### Indicadores

La SMA de longitud `N` en `t` es la media aritmética de exactamente los últimos `N` cierres conocidos, incluido `close[t]`. No utiliza aperturas o cierres futuros. Las ecuaciones impresas del paper tienen un límite de suma que podría leerse como `N+1` términos; se adopta la definición convencional de `N` observaciones.

El régimen es positivo si `SMA_fast > SMA_slow`, negativo si `SMA_fast < SMA_slow` y neutro si son iguales. Para evitar señales por error de redondeo en las sumas acumuladas, diferencias de hasta `1e-12 × max(abs(fast), abs(slow), 1)` se consideran igualdad. En igualdad no se inicia una posición.

### Máquina de estados

Hay cuatro estados: `WAITING_LONG`, `LONG_OPEN`, `WAITING_SHORT` y `SHORT_OPEN`. El inicial es `WAITING_LONG`. Solo se mantiene una posición y no hay inversiones instantáneas en el mismo cierre.

| Estado | Condición observada al cierre | Acción |
|---|---|---|
| `WAITING_LONG` | `fast > slow` | Señal de compra; abrir long en la siguiente apertura. |
| `WAITING_SHORT` | `fast < slow` | Señal de venta; abrir short en la siguiente apertura. |
| `LONG_OPEN` | `close < alpha_long × máximo_observado` y régimen no neutro | Señal de cierre por trailing stop. |
| `LONG_OPEN` | `close > beta_long × precio_entrada` | Señal de cierre por stop-win. |
| `SHORT_OPEN` | `close > alpha_short × mínimo_observado` y régimen no neutro | Señal de cierre por trailing stop. |
| `SHORT_OPEN` | `close < beta_short × precio_entrada` | Señal de cierre por stop-win. |

Después de un stop-win long se espera short; después de un stop-win short se espera long, independientemente del régimen. Después de un trailing stop, el destino sigue las ramas de régimen de la figura 3: un long detenido con régimen negativo vuelve a esperar long, y con régimen positivo pasa a esperar short; un short detenido con régimen positivo vuelve a esperar short, y con régimen negativo pasa a esperar long. En igualdad de medias el trailing no dispara salida y se conserva la posición abierta: la figura literal no tiene una transición para ese caso. Las comparaciones de stop son estrictas; un precio exactamente igual al umbral no dispara salida. Un cambio de régimen por sí solo no cierra una posición.

El máximo o mínimo favorable se inicializa con el precio efectivamente ejecutado de entrada. Después se actualiza con los cierres observados mientras existe la posición. No se utilizan `high` o `low` de la vela de entrada, ni extrema de velas anteriores. Observar un cierre y actualizar el trailing en ese mismo cierre no requiere adivinar un orden intravela.

La señal tomada al cierre de `t` se ejecuta en la apertura de `t+1`, con el deslizamiento configurado. Una salida se ejecuta al precio disponible, aunque haya saltado más allá del umbral. Se registra tanto el cierre de decisión como el precio de fill. Los timestamps de decisión se expresan como `open_time[t] + 15 minutos`: la apertura siguiente puede compartir ese timestamp de frontera, pero corresponde a otra vela y precio. La vela que generó una señal de entrada no se reutiliza después del fill para evaluar stops: el primer cierre elegible es el de la nueva vela.

Un estado de espera puede producir una nueva señal en un cierre posterior a la salida, y esta se ejecutará en su siguiente apertura. No se rellena una entrada con la apertura de la vela que generó su señal. Una señal de entrada en el último cierre no tiene una apertura siguiente dentro de la ventana y no se ejecuta. Si stop-win y trailing resultan verdaderos en el mismo cierre, se prioriza stop-win; esto fija el destino posterior de la FSM de forma determinista.

Toda posición pendiente se liquida obligatoriamente al último cierre de la ventana, con comisión y deslizamiento. Así, beneficio y pérdida pendientes forman parte del resultado. Esta liquidación de frontera no es una decisión de la estrategia: es la convención de valoración común del experimento.

## 4. PnL y costes

Se modela un contrato lineal con liquidación en USDT. Para capital anterior a la entrada `C`, apalancamiento constante `L` y precio ejecutado `P_entry`:

```text
quantity = C × L / P_entry
fee_entry = fee_rate × quantity × P_entry
cash_after_entry = C - fee_entry
unrealized(t) = side × quantity × (P(t) - P_entry)
equity(t) = cash_after_entry + unrealized(t)
fee_exit = fee_rate × quantity × P_exit
C_after_exit = cash_after_entry + side × quantity × (P_exit - P_entry) - fee_exit
```

`side` vale `+1` para long y `-1` para short. La cantidad se mantiene fija durante cada posición; se vuelve a calcular con el capital disponible en la siguiente entrada. Un short de 100 a 90, sin costes y con `L=1`, tiene un factor de capital de 1,10, no `100/90`.

Defaults: `L=1`, `fee_rate=0.0004` por lado, capital inicial 1 y deslizamiento cero. Son hipótesis del experimento; no se presentan como tarifas verificadas de Binance. Un deslizamiento de `s` puntos básicos aumenta el precio de compra y disminuye el precio de venta por un factor `s/10000`, aplicado también al cierre obligatorio.

Funding se omite explícitamente. No se modelan niveles de margen, mantenimiento, liquidation fees ni las reglas del exchange. La condición terminal simplificada de insolvencia es equity no positiva, comprobada en aperturas y cierres, sin detectar liquidaciones intravela: se cierra/bloquea la cuenta, se limita el capital a cero y se considera fracaso de la ventana. No se permite que una cuenta sin capital vuelva a abrir operaciones ni que una insolvencia se transforme en un retorno válido.

Los OHLC siguen siendo útiles para ejecutar en la siguiente apertura y verificar la calidad de los datos; no se emplean para rellenar stops retrospectivamente a precios no disponibles.

## 5. Parámetros y función objetivo

El candidato es una tupla de seis parámetros:

| Parámetro | Dominio de búsqueda | Origen |
|---|---|---|
| `fast` | Entero, 2–1343 | Rango del artículo sujeto a `fast < slow`. |
| `slow` | Entero, 10–1344 | Artículo. |
| `alpha_long` | `[0.9, 1.0)` | Artículo; el extremo abierto se representa con el flotante inmediatamente inferior a 1. |
| `alpha_short` | `(1.0, 1.1]` | Artículo; el extremo abierto se representa con el flotante inmediatamente superior a 1. |
| `beta_long` | `[1.001, 4.0]` | Elección de esta réplica. |
| `beta_short` | `[0.1, 0.999]` | Elección de esta réplica. |

Siempre se exige `fast < slow`. SHO trabaja en seis coordenadas normalizadas en `[0,1]`. Los movimientos se proyectan al dominio, las dos longitudes se discretizan a enteros y se repara la relación entre medias de forma determinista. El candidato reparado, no el vector continuo original, es el que recibe fitness y aparece en resultados. No se reutiliza fitness entre candidatos distintos.

Para cada ventana train `i` se calcula el factor neto `R_i = C_final_i / C_initial_i`. La función a maximizar es:

```text
fitness = mean(log(R_i))
geometric_factor = exp(fitness)
geometric_return = geometric_factor - 1
```

Una ventana insolvente o un factor no positivo invalida el candidato, con fitness `-inf`. Una ventana sin operaciones tiene factor 1 y aporta 0 al fitness. Todas las ventanas tienen el mismo peso. La media geométrica describe ventanas independientes inicializadas de nuevo; no expresa una inversión continua a lo largo de ventanas solapadas.

Test no participa en evaluaciones del optimizador, ruletas, regresiones, elección de semillas ni selección de parámetros. El objetivo opera sobre un `MarketData` limitado al prefijo que termina en la última ventana train, con su propio cache de indicadores; sus arrays públicos no incluyen precios de test. Se evalúa una vez la configuración final seleccionada mediante train. El flujo actual ejecuta un holdout cronológico y una semilla, no 34 particiones experimentales ni pruebas de Wilcoxon. Si se realizan varias ejecuciones, deben informarse todas las semillas y sus resultados; elegir el mejor test entre ellas convierte test en validación de selección.

## 6. LB² implementado

LB² combina una población SHO con un aprendizaje de la intensidad de exploración y explotación. No es una búsqueda aleatoria con el nombre LB²: se mantienen población, operadores de movimiento, dos ruletas independientes, registros de mejora y seis ajustes lineales.

### Ciclo de búsqueda

1. Inicializar el generador aleatorio local con una semilla registrada y una población en el dominio; evaluar los candidatos sobre train. El flujo de experimento incluye la configuración publicada como primer agente si está dentro del dominio configurado; el resto es aleatorio. Un dominio reducido que excluya esa configuración utiliza una población totalmente aleatoria.
2. En cada iteración y para cada agente, seleccionar por la ruleta de intensificación el esquema Soft, Medium o Hard y efectuar 1, 2 o 3 movimientos, respectivamente.
3. Registrar los fitness personales mejorados atribuidos al esquema de intensificación.
4. Seleccionar independientemente por la ruleta de diversificación el esquema Soft, Medium o Hard y efectuar 1, 2 o 3 movimientos.
5. Registrar sus mejoras y actualizar la mejor solución global evaluada.
6. Cada `learning_interval` iteraciones, ajustar las regresiones y actualizar por separado ambas ruletas.
7. Terminar al alcanzar el número fijado de iteraciones; devolver la mejor solución real evaluada, no una predicción del regresor.

Las propuestas se aceptan de forma greedy cuando mejoran estrictamente el fitness personal; se conserva una élite global independiente y se reintroduce reemplazando al peor agente si fuera necesario. Esta política de aceptación completa un detalle no fijado en el artículo. La memoización usa la tupla canónica exacta de los seis parámetros; las coordenadas continuas no se redondean para compartir fitness entre estrategias parecidas. Su validez requiere un objetivo determinista. Predicciones y probabilidades nunca sustituyen evaluaciones de mercado reales.

`-inf` representa un candidato insolvente/inviable y siempre pierde frente a un fitness finito. Una población inicial completamente inviable puede seguir explorando; si no encuentra ningún candidato finito en todo el presupuesto, la optimización termina con un error concreto. `NaN` y `+inf` no son fitness válidos y se rechazan. Los valores no finitos de las trazas, incluida una élite inicial inviable o la mejora medida desde `-inf`, se serializan como `null` en JSON, evitando valores no estándar como `Infinity`.

### Operadores SHO

Se emplean los coeficientes del artículo `B=2×U(0,1)` y `E=2×h×U(0,1)-h`, con reducción lineal de `h` desde 5 hasta 0 durante el presupuesto de búsqueda. Las distancias de caza se calculan en el espacio normalizado, evitando que las longitudes de SMA dominen a los multiplicadores por su escala numérica.

La intensificación sigue el ataque del clúster `C_h / N`. El clúster incluye la élite y sus vecinos cuya distancia absoluta a la élite en **cada coordenada** es menor o igual al correspondiente componente de un vector `M`, muestreado independientemente en `[0.5,1]` para las seis coordenadas; no es un radio euclídeo. `N` es su cardinalidad, siempre al menos uno. Se promedian las posiciones de caza de sus miembros. En diversificación se buscan agentes aleatorios cuando `max(abs(E)) >= 1`; de lo contrario se elige entre rodear y cazar con igual probabilidad. Rodear usa la distancia con signo impresa en la ecuación 1; cazar utiliza distancia absoluta. Esta elección hace operativa la descripción parcialmente ambigua de `countnos` del paper. La proyección al dominio ocurre antes de evaluar cualquier propuesta.

### Aprendizaje del balance

Inicialmente las probabilidades de cada ruleta son `(1/3, 1/3, 1/3)`. Hay seis series independientes: intensificación y diversificación, cada una con Soft, Medium y Hard. En cada serie se ajusta por mínimos cuadrados:

```text
predicted_fitness(iteration) = slope × iteration + intercept
```

Los registros son `(iteración, agente, esquema, fitness_personal_mejorado)` y se atribuyen a la fase y esquema ejecutados. Se conserva el historial completo entre intervalos de aprendizaje. Para ajustar cada regresión se toma solo el mejor fitness registrado por esquema en cada iteración, evitando tratar varios agentes de una misma iteración como réplicas temporales. Se predice el fitness en `iteración_actual + learning_interval`. Se selecciona mediante **MAX**, porque este experimento maximiza rentabilidad; el `MIN` de los algoritmos originales responde a sus funciones benchmark de minimización.

La ruleta con un ganador identificable asigna por defecto `(0.6,0.2,0.2)` con 0.6 en el esquema ganador. `winner_probability` es configurable y el resto se divide igualmente. Debe haber al menos dos iteraciones distintas con mejoras para cada uno de sus tres esquemas; si a alguno le faltan observaciones, aparecen predicciones no finitas o empatan las máximas (`rtol=1e-9`, `atol=1e-12`), toda esa ruleta vuelve a uniforme. Nunca se inventa una pendiente a partir de una sola observación. Los registros de mejoras condicionan el aprendizaje a eventos favorables y no demuestran una relación causal ni ausencia de sesgo entre esquemas; son una decisión operativa documentada.

### Presupuesto y reproducibilidad

Los valores prácticos iniciales son **20 agentes, 100 iteraciones, `learning_interval=20` y semilla 42**. No son los valores del estudio de 2021: ese trabajo describe `beta=1000` y para SHO 30 agentes y 10 000 generaciones. Se pueden configurar presupuestos mayores; las cifras y el número efectivo de evaluaciones, aciertos de cache y movimientos intentados se guardan con cada ejecución. Una iteración no equivale a un número fijo de evaluaciones: el coste depende de los esquemas seleccionados, candidatos repetidos, cantidad y longitud de ventanas y entorno de ejecución. No se promete un tiempo de ejecución del artículo. El intervalo de aprendizaje se denomina `learning_interval` para no confundirlo con `beta_long` y `beta_short`.

El resultado debe guardar la semilla, parámetros del optimizador, límites, candidato ganador, fitness train, historia del mejor fitness, cambios de probabilidades y conteo de evaluaciones. La misma entrada y configuración deben producir el mismo resultado numérico en el mismo entorno.

## 7. Comparaciones

Todos los métodos se evalúan sobre las mismas ventanas, capital inicial, costes y liquidación de frontera:

- **Configuración publicada:** `fast=171`, `slow=356`, `alpha_long=0.972`, `alpha_short=1.023`, `beta_long=3.447`, `beta_short=0.472` (tabla 3). Es una referencia fija, no una ejecución local de LB².
- **2-SMA fija:** `fast=50`, `slow=200`, `alpha_long=0.95`, `alpha_short=1.05`, `beta_long=1.10`, `beta_short=0.90` (sección 7.3).
- **Buy and Hold:** comprar al primer open evaluado y vender al último close, cobrando ambos lados. No necesita señal ni consulta cierres futuros para decidir su entrada.
- **Random Walk:** calibrar media y desviación muestral (`ddof=1`) de retornos simples `close[t]/close[t-1]-1` únicamente con pares de timestamps adyacentes contenidos en train. Una máscara sobre la serie original deduplica los retornos de ventanas solapadas. Para cada ventana se generan por defecto 100 trayectorias normales independientes, con `seed + window_id`; cada trayectoria tiene `n_velas - 1` pasos y representa una cuenta long sintética de cantidad fija, con los mismos costes. Se informan media y percentiles 5 y 95 de sus factores. Un retorno muestreado menor o igual a -1 o equity observada no positiva implica factor cero. La simulación es una referencia de precios estocásticos y no se presenta como una política predictiva de inversión ni como Random Forest.

No se estima la distribución del Random Walk con los precios de la ventana test. No se configura una estrategia o se elige una semilla aleatoria para obtener un benchmark desfavorable. Su política y parámetros deben figurar en el artefacto de resultados.

Se informan por método factores individuales y resúmenes train/test separados: media geométrica, retorno geométrico porcentual, media aritmética, desviación muestral, mínimo, máximo y ventanas rentables/insolventes. El API del simulador retorna cantidad de operaciones, transiciones y detalle de trades; el comando `simulate` conserva ese detalle en su JSON. El flujo `run` exporta los trades, las comparaciones y resúmenes, y opcionalmente la curva equity. Para Random Walk, el resumen entre ventanas utiliza la media aritmética Monte Carlo de cada ventana como su factor; no es una media geométrica sobre todas las trayectorias. Sus trayectorias no se cuentan como nuevas ventanas test independientes. Se diferencia siempre «factor de capital 1.10» de «retorno 10%». Las tablas originales no se copian como resultados nuevos y no se presupone que LB² deba superar las referencias.

`compare` compara una configuración seleccionada, 2-SMA fija y Buy and Hold. La configuración publicada aparece como la seleccionada si se solicita esa referencia; en una ejecución optimizada no constituye automáticamente una cuarta estrategia separada. Esto mantiene distinguibles una simulación de parámetros publicados y una configuración aprendida localmente.

## 8. Verificación y artefactos

La verificación con datos sintéticos debe cubrir causalidad de fills, stops posteriores a la entrada, saltos de precio, PnL long/short, comisiones, liquidación al final, ausencia de señales, destino de estados, separación temporal, warm-up común, dominio de parámetros y actualización de las ruletas. Un problema matemático con óptimo conocido sirve para comprobar que LB² maximiza y conserva el mejor candidato antes de conectarlo al mercado.

El flujo `run` exporta los siguientes archivos dentro del directorio de salida:

| Archivo | Contenido |
|---|---|
| `experiment.json` | Ruta absoluta y SHA-256 del CSV, versiones Python/NumPy, configuración de ventanas, costes, LB², dominio y cantidad de ventanas train/test/purgadas. |
| `windows.csv` | Manifiesto con IDs, fechas UTC, índices, cantidad de filas y split de todas las ventanas, incluidas las purgadas. |
| `parameters.json` | Candidato seleccionado, fitness train, configuración de simulación e identificación del CSV. |
| `optimizer.json` | Configuración, mejor candidato, evolución del fitness, intentos de movimiento, evaluaciones, cache y registros/modelos/probabilidades del aprendizaje. |
| `evaluation.json` | Calibración y réplicas de Random Walk, factores por ventana y resúmenes train/test separados. |
| `comparison.csv` | Comparación por ventana y percentiles Monte Carlo del Random Walk. |
| `trades.csv` | Entradas/salidas, señal, lado, cantidad, motivo de salida, comisiones, PnL y capital de cada trade de las estrategias reales. |
| `equity.csv` | Curvas de equity observada por ventana y estrategia, únicamente con `--save-equity`. |
| `roi_by_window.png`, `capital_by_test_window.png` | Gráficos comparativos, únicamente con `--plots` y Matplotlib. El capital se muestra por ventana independiente, sin acumular periodos solapados. |

`optimize` exporta el manifiesto, configuración, parámetros y traza del optimizador sin evaluar test. `baselines` exporta la comparación, trades, manifiesto y `source.json` para una configuración fija. Para reproducir una ejecución archivada también debe conservarse esta versión del código, por ejemplo mediante el commit del repositorio o una copia del árbol fuente; la CLI registra las versiones Python/NumPy, pero no genera automáticamente un identificador de revisión del código.

Al reutilizar `parameters.json` con `simulate` o `baselines`, se heredan sus costes y exposición guardados, salvo que se indiquen argumentos explícitos que los sustituyan. El subcomando `plot --fsm` exporta el gráfico y un JSON adjunto con la simulación del mismo motor, incluidos origen, parámetros y costes. Los cierres y SMA se dibujan en sus timestamps de cierre para alinearlos con las decisiones y fills.

Los tests sintéticos verifican la implementación; no establecen rentabilidad sobre BTCUSDT. Mientras no se proporcione y ejecute un CSV local válido, no hay resultados financieros medidos que informar. El programa debe rechazar problemas de entrada y emitir errores concretos, sin recurrir a descargas automáticas.

## 9. Ejecución local

La interfaz se ejecuta desde la raíz del repositorio. Los subcomandos `audit`, `windows`, `simulate`, `baselines`, `optimize`, `run` y `plot` consultan únicamente archivos locales. El flujo completo se inicia con:

```bash
python -m trading.cli run --data /ruta/al/ohlcv_local.csv --output results/experiment
```

El CSV debe cumplir la entrada y cobertura descritas arriba. Los defaults constituyen una sola ejecución del experimento definido; los parámetros de ventanas, costes, presupuesto y semilla pueden cambiarse explícitamente desde la CLI. No hay descarga automática si falta el archivo. Usar `python -m trading.cli --help` y la ayuda del subcomando permite comprobar las opciones disponibles.
